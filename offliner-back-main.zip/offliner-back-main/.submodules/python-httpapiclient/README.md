# Python HTTP API Client

Requirements:

* Python 3.6+

Features:

* smart retry (only if failed request had no side effects)  
* response validation using JSON Schema (optional)
* detailed errors
* highly extendable and customizable
