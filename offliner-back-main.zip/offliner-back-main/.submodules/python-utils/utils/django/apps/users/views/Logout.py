from utils.django.auth.views import LogoutView as BaseLogoutView


class LogoutView(BaseLogoutView):
    pass
