from django.urls import path

from utils.django.routers import Router

from offliner.users import views


router = Router()

router.register('me/personal_management', views.CurrentUserManagersViewSet)
router.register(r'(?P<user_id>\d+)/personal_management', views.UserManagersViewSet)


urlpatterns = [
    path('me', views.AboutUserAPIView.as_view()),
    path('token-refresh', views.RefreshTokenAPIView.as_view()),
    path('signin', views.SignInUserAPIView.as_view()),
    path('signup', views.SignUpAPIView.as_view()),
    path('signout', views.LogoutAPIView.as_view()),
] + router.urls
