from django.contrib.auth import get_user_model
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import viewsets

from utils.django.apps.users.views import MeView
from utils.django.auth.serializers import LoginSerializer
from utils.django.auth.views import LoginView, SignupView

from offliner.users import login, logout
from offliner.users.permissions import CanViewPersonalManagers
from offliner.users.serializers import (
    JSONWebTokenResponseSerializer, UserSerializer,
    RefreshTokenSerializer, SignupSerializer, LogoutSerializer,
    UpdateUserSerializer,
)
from offliner.views.mixins import ChangeOperationIdForSchemaMixin
from offliner.views import ListModelMixin


class GetJSONWebTokenResponseMixin:
    user_serializer_class = JSONWebTokenResponseSerializer

    def get_success_response(self, user, serializer):
        serializer = self.user_serializer_class(instance=user, data=serializer.data)
        serializer.is_valid(raise_exception=True)
        result = serializer.validated_data
        return Response(result)


class AboutUserAPIView(ChangeOperationIdForSchemaMixin, MeView):
    permission_classes = (IsAuthenticated, )
    method_to_operation_id = {'get': 'info_about_me'}
    serializer_class = UserSerializer
    http_method_names = ['get', 'patch', 'head', 'options', 'trace']

    def get_serializer_class(self):
        serializer_class = self.serializer_class

        if self.request.method == 'PATCH':
            serializer_class = UpdateUserSerializer

        return serializer_class


class RefreshTokenAPIView(ChangeOperationIdForSchemaMixin, APIView):
    permission_classes = (AllowAny, )
    method_to_operation_id = {'post': 'refresh_token'}

    def post(self, request):
        serializer = RefreshTokenSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        return Response(serializer.validated_data)


class SignInUserAPIView(ChangeOperationIdForSchemaMixin, GetJSONWebTokenResponseMixin, LoginView):
    method_to_operation_id = {'post': 'sign_in'}

    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data
        login(request, user)
        return self.get_success_response(user, serializer)


class SignUpAPIView(ChangeOperationIdForSchemaMixin, GetJSONWebTokenResponseMixin, SignupView):
    serializer_class = SignupSerializer
    method_to_operation_id = {'post': 'sign_up'}

    def perform_create(self, serializer):
        user = serializer.save()
        if self.do_login:
            login(self.request, user)
        self.user = user
        self.serializer = serializer


class LogoutAPIView(ChangeOperationIdForSchemaMixin, APIView):
    method_to_operation_id = {'post': 'sign_out'}

    def post(self, request):
        serializer = LogoutSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        logout(request)
        return Response()


class BaseUserManagersViewSet(ListModelMixin, viewsets.GenericViewSet):
    permission_classes = (IsAuthenticated, )
    serializer_class = UserSerializer
    queryset = get_user_model().objects.all()

    def get_queryset(self):
        queryset = super().get_queryset()
        return queryset.filter(managed_users=self.get_user_id())

    def get_user_id(self):
        raise NotImplementedError


class CurrentUserManagersViewSet(BaseUserManagersViewSet):

    def get_user_id(self):
        return self.request.user


class UserManagersViewSet(BaseUserManagersViewSet):
    permission_classes = (IsAuthenticated, CanViewPersonalManagers)

    def get_user_id(self):
        return self.kwargs.get('user_id')
