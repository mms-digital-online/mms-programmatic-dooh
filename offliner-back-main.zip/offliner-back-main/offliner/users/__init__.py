from django.contrib.auth import user_logged_in, user_logged_out


def login(request, user, backend=None):
    """ Analogue of django.contrib.auth.login but without session usage """
    if user is None:
        user = request.user

    if hasattr(request, 'user'):
        request.user = user
    user_logged_in.send(sender=user.__class__, request=request, user=user)


def logout(request):
    """ Analogue of django.contrib.auth.logout but without session usage """
    user = getattr(request, 'user', None)
    if not getattr(user, 'is_authenticated', True):
        user = None
    user_logged_out.send(sender=user.__class__, request=request, user=user)
    if hasattr(request, 'user'):
        from django.contrib.auth.models import AnonymousUser
        request.user = AnonymousUser()
