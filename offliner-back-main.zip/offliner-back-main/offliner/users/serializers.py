from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group

from rest_framework import serializers
from rest_framework.exceptions import ValidationError, PermissionDenied
from rest_framework_simplejwt.exceptions import TokenError
from rest_framework_simplejwt.settings import api_settings
from rest_framework_simplejwt.tokens import RefreshToken

from utils.django.auth.serializers import PasswordMixin
from utils.django.serializers.fields import PasswordField

from offliner.users.models import UserToManagerLink


class UserSerializer(PasswordMixin, serializers.ModelSerializer):
    group_id = serializers.IntegerField(write_only=True)
    password = PasswordField(write_only=True)
    assigned_users = serializers.JSONField(read_only=True)
    phone_number = serializers.RegexField(r'^\+?1?\d{9,15}$')
    details = serializers.CharField()

    class Meta:
        model = get_user_model()
        fields = (
            'id', 'email', 'first_name', 'last_name', 'role', 'group_id', 'password', 'assigned_users',
            'phone_number', 'details',
        )

    def to_internal_value(self, data):
        if 'role' in data:
            group_name = data.pop('role')
            try:
                data['group_id'] = Group.objects.values_list('pk', flat=True).get(name=group_name)
            except Group.DoesNotExist:
                raise ValidationError({'role': [f'Role {group_name} not found']})

        return super().to_internal_value(data)

    def to_representation(self, instance):
        ret = super().to_representation(instance)
        request_user = self.context['request'].user
        if instance.id != request_user.id:
            if not request_user.has_perm('users.can_see_other_users_email'):
                ret.pop('email', None)
        return ret

    def validate(self, attrs):
        if 'group_id' in attrs:
            if not self.context['request'].user.has_perm('users.can_change_user_role'):
                raise PermissionDenied(
                    detail='You have no permission to change user role',
                    code='can_not_change_role'
                )
        attrs = super().validate(attrs)
        return attrs


class UpdateUserSerializer(UserSerializer):
    class Meta:
        model = get_user_model()
        fields = (
            'id', 'email', 'first_name', 'last_name', 'role', 'group_id', 'password', 'assigned_users',
            'phone_number', 'details',
        )
        read_only_fields = ('email', 'assigned_users')


class JSONWebTokenResponseSerializer(serializers.Serializer):

    @classmethod
    def get_token(cls, user):
        return RefreshToken.for_user(user)

    def validate(self, attrs):
        data = super().validate(attrs)

        refresh_obj = self.get_token(self.instance)
        data['access_token'] = str(refresh_obj.access_token)
        data['refresh_token'] = str(refresh_obj)
        return data


class RefreshTokenSerializer(serializers.Serializer):
    refresh_token = serializers.CharField()
    access_token = serializers.CharField(required=False)

    def validate(self, attrs):
        try:
            refresh_obj = RefreshToken(attrs['refresh_token'])
        except TokenError:
            raise ValidationError({'refresh_token': ['Invalid token']})

        if api_settings.BLACKLIST_AFTER_ROTATION:
            refresh_obj.blacklist()

        refresh_obj.set_jti()
        refresh_obj.set_exp()

        return {
            'access_token': str(refresh_obj.access_token),
            'refresh_token': str(refresh_obj),
        }


class SignupSerializer(PasswordMixin, serializers.ModelSerializer):
    class Meta:
        model = get_user_model()
        fields = (
            model.USERNAME_FIELD,
            'password',
            'first_name',
            'last_name',
            'details',
            'phone_number',
        ) + tuple(get_user_model().REQUIRED_FIELDS)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        not_required_fields = (
            'password',
            'first_name',
            'last_name',
            'details',
            'phone_number',
        )
        for field in not_required_fields:
            self.fields[field].required = False

    def create(self, validated_data):
        validated_data['group'] = Group.objects.filter(name='client').first()
        user = super().create(validated_data)
        return user


class LogoutSerializer(serializers.Serializer):
    refresh_token = serializers.CharField()

    def validate(self, attrs):
        try:
            refresh_obj = RefreshToken(attrs['refresh_token'])
        except TokenError:
            raise ValidationError({'refresh_token': ['Invalid token']})
        refresh_obj.blacklist()
        return attrs


class GroupSerializer(serializers.ModelSerializer):

    class Meta:
        model = Group
        fields = ('id', 'name')


class UserToManagerLinkSerializer(serializers.ModelSerializer):

    class Meta:
        model = UserToManagerLink
        fields = ('id', 'user', 'manager')

    def validate(self, attrs):
        attrs = super().validate(attrs)
        if 'manager' in attrs:
            if not attrs['manager'].has_perm('users.can_manage_users'):
                raise ValidationError(
                    {'manager': [f'User with id = {attrs["manager"]} can not manage clients personally']}
                )
        return attrs
