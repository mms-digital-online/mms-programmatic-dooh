from django.contrib.auth.models import Permission
from django.db import models

from utils.django.apps.users.models import AbstractUser


class User(AbstractUser):
    groups = None
    user_permissions = None

    group = models.ForeignKey('auth.Group', null=True, on_delete=models.SET_NULL)
    managed_devices = models.ManyToManyField('offliner.Device', related_name='managed_by')
    managed_users = models.ManyToManyField('users.User', related_name='managed_by', through='UserToManagerLink')
    phone_number = models.CharField(blank=True, default='', max_length=30)
    details = models.CharField(
        blank=True, default='', max_length=255, help_text='Organization name or user`s full name',
    )

    @property
    def role(self) -> str:
        if self.group:
            return self.group.name
        else:
            return ''

    @property
    def assigned_users(self):
        return tuple(self.managed_users.all().values_list('pk', flat=True))

    def get_permissions(self):
        if not self.is_active or self.is_anonymous:
            return set()
        elif self.is_superuser:
            perms = Permission.objects.all()
        else:
            user_groups_field = self._meta.get_field('group')
            user_groups_query = 'group__%s' % user_groups_field.related_query_name()
            perms = Permission.objects.filter(**{user_groups_query: self})
        return {
            f"{ct}.{name}" for ct, name in perms.values_list('content_type__app_label', 'codename').order_by()
        }

    def has_perm(self, perm, obj=None):
        return perm in self.get_permissions()

    class Meta:
        permissions = (
            ('has_access_to_admin', 'Has access to administration page'),
            ('can_manage_users', 'Can manage users'),
            ('can_manage_devices', 'Can manage devices'),
            ('can_see_other_users_email', 'Can see other users email'),
            ('can_change_user_role', 'Can change user role'),
        )


class UserToManagerLink(models.Model):
    manager = models.ForeignKey('User', on_delete=models.CASCADE, related_name='links_to_managed_users')
    user = models.ForeignKey('User', on_delete=models.CASCADE, related_name='links_to_managers')

    class Meta:
        unique_together = ('user', 'manager')
