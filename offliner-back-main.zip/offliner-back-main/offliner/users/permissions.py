from rest_framework.permissions import BasePermission, DjangoModelPermissions as BaseDjangoModelPermissions


class HasAccessToAdministrationPage(BasePermission):
    def has_permission(self, request, view):
        return bool(
            request.user and request.user.has_perm('users.has_access_to_admin')
        )


class CanViewAllAdCampaigns(BasePermission):
    def has_permission(self, request, view):
        return bool(
            request.user and request.user.has_perm('offliner.view_all_adcampaigns')
        )


class CanViewAllMedia(BasePermission):
    def has_permission(self, request, view):
        return bool(
            request.user and request.user.has_perm('offliner.view_all_media')
        )


class CanViewPersonalManagers(BasePermission):
    def has_permission(self, request, view):
        return bool(
            request.user and request.user.has_perm('users.view_usertomanagerlink')
        )


class DjangoModelPermissions(BaseDjangoModelPermissions):
    perms_map = {
        'GET': ['%(app_label)s.view_%(model_name)s'],
        'OPTIONS': [],
        'HEAD': [],
        'POST': ['%(app_label)s.add_%(model_name)s'],
        'PUT': ['%(app_label)s.change_%(model_name)s'],
        'PATCH': ['%(app_label)s.change_%(model_name)s'],
        'DELETE': ['%(app_label)s.delete_%(model_name)s'],
    }


class IsSuperUser(BasePermission):
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_superuser)
