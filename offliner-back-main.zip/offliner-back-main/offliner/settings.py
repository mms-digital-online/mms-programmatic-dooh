# flake8: noqa: F405
from datetime import timedelta

from celery.schedules import crontab
from google.oauth2 import service_account

from utils.django.settings import *

from offliner.log_config import OfflinerLoggingConfig

TIME_ZONE = env('TIME_ZONE', default='Europe/Moscow')
USE_TZ = env('USE_TZ', default=True)
CELERY_TIMEZONE = TIME_ZONE
CELERY_TASK_SOFT_TIME_LIMIT = env('CELERY_TASK_SOFT_TIME_LIMIT', default=60 * 60)
CELERY_TASK_TIME_LIMIT = CELERY_TASK_SOFT_TIME_LIMIT + CELERY_TASK_CLEANUP_TIMEOUT
CELERY_WORKER_CONCURRENCY = env('CELERY_WORKER_CONCURRENCY', default=None)
CELERY_BROKER_TRANSPORT_OPTIONS = {'visibility_timeout': 3600*240}

env.scheme['DSEE_USERNAME'] = (str, None)
env.scheme['DSEE_PASSWORD'] = (str, None)

DSEE_USERNAME = env('DSEE_USERNAME')
DSEE_PASSWORD = env('DSEE_PASSWORD')

DSEE_SYSTEM_URL = env('DSEE_SYSTEM_URL', default='https://cloud-eu.dseelab.com/')
DSEE_TASK_WAITING_MAX_RETRIES = env('DSEE_TASK_WAITING_MAX_RETRIES', default=40)
DSEE_TASK_WAITING_INTERVAL = env('DSEE_TASK_WAITING_INTERVAL', default=10)
DSEE_TASK_TIMEOUT_MAX_RETRIES = env('DSEE_TASK_TIMEOUT_MAX_RETRIES', default=3)
DSEE_MEDIA_PER_PLAYLIST = env('DSEE_MEDIA_PER_PLAYLIST', default=50)
DSEE_PLAYLIST_SAVE_TIME = env('DSEE_PLAYLIST_SAVE_TIME', default=30)
DSEE_TASK_REQUEST_PAGE_SIZE = env('DSEE_TASK_REQUEST_PAGE_SIZE', default=20)

DEVICE_SYNC_RETRY_INTERVAL = env('DEVICE_SYNC_RETRY_INTERVAL', default=10 * 60)

MEDIA_ROOT = env('MEDIA_ROOT', default='./.data/media')

INSTALLED_APPS.extend([
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'rest_framework',
    'rest_framework_simplejwt.token_blacklist',
    'offliner.users',
    'offliner.media',
])

AUTH_USER_MODEL = 'users.User'

CELERY_BEAT_SCHEDULE = {
    'sync-all-devices-at-night': {
        'task': 'offliner.tasks.sync_all_devices',
        'schedule': crontab(hour=1, minute=0),
    },
    'update-campaigns-statuses-at-night': {
        'task': 'offliner.tasks.update_campaigns_statuses',
        'schedule': crontab(hour=1, minute=0),
    },
}

REDIS_TOKEN_STORAGE_KEY = env('REDIS_TOKEN_STORAGE_KEY', default='dsee_tokens')

REST_FRAMEWORK.setdefault('DEFAULT_AUTHENTICATION_CLASSES', [])
REST_FRAMEWORK['DEFAULT_AUTHENTICATION_CLASSES'].append(
    'rest_framework_simplejwt.authentication.JWTAuthentication'
)
REST_FRAMEWORK['ORDERING_PARAM'] = 'sort'
REST_FRAMEWORK['DEFAULT_PAGINATION_CLASS'] = 'offliner.views.pagination.PageNumberPagination'
REST_FRAMEWORK['EXCEPTION_HANDLER'] = 'offliner.views.utils.custom_exception_handler'

SIMPLE_JWT = {
    'ROTATE_REFRESH_TOKENS': True,
    'ACCESS_TOKEN_LIFETIME': timedelta(
        minutes=env('JWT_ACCESS_TOKEN_LIFETIME', default=5),
    ),
}

USE_GS = not DEBUG or env('USE_GS', default=False)

if USE_GS:
    DEFAULT_FILE_STORAGE = 'storages.backends.gcloud.GoogleCloudStorage'
    STATICFILES_STORAGE = 'storages.backends.gcloud.GoogleCloudStorage'

    GS_BUCKET_NAME = env('GS_BUCKET_NAME', default='offliner-dev')
    GS_CREDENTIALS = service_account.Credentials.from_service_account_file(env('GS_CREDENTIALS_FILE', default=''))

if DEBUG and env('ALLOW_CORS', default=True):
    CORS_ALLOW_ORIGIN = env('CORS_ALLOW_ORIGIN', default='*')
    MIDDLEWARE.append('offliner.middleware.allow_cors_middleware')

THUMBNAIL_MAX_WIDTH_PX = env('THUMBNAIL_MAX_WIDTH_PX', default=300)
THUMBNAIL_MAX_HEIGHT_PX = env('THUMBNAIL_MAX_HEIGHT_PX', default=170)

DEFAULT_DEVICE_TURN_ON_HOUR = env('DEFAULT_DEVICE_TURN_ON_HOUR', default=7)
DEFAULT_DEVICE_TURN_OFF_HOUR = env('DEFAULT_DEVICE_TURN_OFF_HOUR', default=22)

# TODO move to database
PRICE_PER_SHOW = env('PRICE_PER_SHOW', default=50)  # in rub

AD_CAMPAIGN_PRE_SAVE_CHECKS_FOR_DEVICE_OVERLOAD = env('AD_CAMPAIGN_PRE_SAVE_CHECKS_FOR_DEVICE_OVERLOAD', default=True)

###
# Logging
###
LOGGING = OfflinerLoggingConfig()
LOGGING.enable_handler(env('LOGGING'))
if env('SENTRY_DSN'):
    LOGGING.enable_handler('sentry_django')
if not env('SQL_LOGGING'):
    LOGGING.set_logger_level('django.db.backends', 'INFO')
