from typing import Dict

from rest_framework.exceptions import ValidationError
from rest_framework.response import Response


class ChangeOperationIdForSchemaMixin:
    method_to_operation_id: Dict[str, str] = {}

    @classmethod
    def as_view(cls, **kwargs):
        result = super().as_view(**kwargs)
        result.actions = cls.method_to_operation_id
        return result


class ListModelMixin:
    """ List a queryset handling exceptions of his filtering """
    def list(self, request, *args, **kwargs):
        page = None
        errors = []

        queryset = self.get_queryset()
        try:
            queryset = self.filter_queryset(queryset)
        except ValidationError as e:
            errors.append(e.get_full_details())

        try:
            self.paginator.validate_request(self.request)
        except ValidationError as e:
            errors.append(e.get_full_details())
        except AttributeError:
            pass
        page = self.paginate_queryset(queryset)

        if page is not None:
            serializer = self.get_serializer(page, many=True)
            response = self.get_paginated_response(serializer.data)
        else:
            serializer = self.get_serializer(queryset, many=True)
            response = Response(serializer.data)

        try:
            serializer.validate_request(self.request)
        except ValidationError as e:
            errors.append(e.get_full_details())
        except AttributeError:
            pass

        if errors and isinstance(response.data, dict):
            response.data['errors'] = errors
        return response
