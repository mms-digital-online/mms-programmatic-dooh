from django.db.models import Q
from django_filters import rest_framework as filters
from rest_framework.exceptions import ValidationError
from rest_framework.mixins import RetrieveModelMixin, CreateModelMixin, UpdateModelMixin
from rest_framework.permissions import IsAuthenticated
from rest_framework.viewsets import GenericViewSet

from utils.django.filters import FilterSet

from offliner.models import Device, AdCampaign
from offliner.serializers import DeviceSerializer, AdCampaignSerializer
from offliner.users.permissions import DjangoModelPermissions
from offliner.views.mixins import ListModelMixin


class BaseOwnerFilterSet(FilterSet):
    user_lookup = None
    manager_lookup = None
    allowed_values = ('id', 'me', 'assigned', 'any')

    owner = filters.CharFilter(method='owner_filter')

    def owner_filter(self, queryset, name, value):
        if value.isdigit() and 'id' in self.allowed_values:
            queryset = queryset.filter(**{self.get_user_lookup(): value})
        elif value == 'me' and 'me' in self.allowed_values:
            queryset = queryset.filter(**{self.get_user_lookup(): self.request.user.id})
        elif value == 'assigned' and 'assigned' in self.allowed_values:
            queryset = queryset.filter(**{self.get_manager_lookup(): self.request.user.id})
        elif value == 'any' and 'any' in self.allowed_values:
            pass
        else:
            raise ValidationError({'owner': ['Wrong value']})
        return queryset

    def get_user_lookup(self):
        if self.user_lookup is None:
            raise ValidationError({'owner': ['Wrong value']})
        return self.user_lookup

    def get_manager_lookup(self):
        if self.manager_lookup is None:
            raise ValidationError({'owner': ['Wrong value']})
        return self.manager_lookup


class OwnerFilterSetForModelWithCreator(BaseOwnerFilterSet):
    user_lookup = 'creator_id'
    manager_lookup = 'creator__managed_by'


class DeviceViewSet(RetrieveModelMixin, ListModelMixin, GenericViewSet):
    permission_classes = (IsAuthenticated, DjangoModelPermissions)
    serializer_class = DeviceSerializer
    queryset = Device.objects.select_related('location').all()


class AdCampaignFilterSet(OwnerFilterSetForModelWithCreator):
    search = filters.CharFilter(field_name='name', lookup_expr='icontains')

    class Meta:
        model = AdCampaign
        fields = ['search', 'status', 'visible', 'owner']


class BaseAdCampaignViewSet(GenericViewSet):
    permission_classes = (IsAuthenticated, DjangoModelPermissions)
    serializer_class = AdCampaignSerializer
    filterset_class = AdCampaignFilterSet
    queryset = AdCampaign.objects.select_related(
        'creator',
    ).prefetch_related(
        'orderedmediafordevice_set',
    ).all()


class FilteredAdCampaignViewSet(CreateModelMixin, ListModelMixin, BaseAdCampaignViewSet):
    def get_queryset(self):
        result = super().get_queryset()
        return result.filter(creator=self.request.user)


class UnfilteredAdCampaignViewSet(RetrieveModelMixin, UpdateModelMixin, BaseAdCampaignViewSet):
    pass
