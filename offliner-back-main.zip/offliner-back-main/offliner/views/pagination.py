from distutils.util import strtobool

from rest_framework.exceptions import ValidationError
from rest_framework.pagination import PageNumberPagination as BasePageNumberPagination


class PageNumberPagination(BasePageNumberPagination):
    page_size = 6
    page_size_query_param = 'items'

    def validate_request(self, request):
        all_value = request.query_params.get('all', '0')
        try:
            strtobool(all_value)
        except ValueError:
            raise ValidationError({'all': ['Wrong value']})

    def paginate_queryset(self, queryset, request, view=None):
        all_value = request.query_params.get('all', '0')
        try:
            all_value = strtobool(all_value)
        except ValueError:
            all_value = False

        return None if all_value else super().paginate_queryset(queryset, request, view)
