from django.conf import settings
from django.http.response import HttpResponse


def allow_cors_middleware(get_response):
    def middleware(request):
        if request.method == 'OPTIONS':
            response = HttpResponse()
        else:
            response = get_response(request)
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = ', '.join([
            'accept',
            'accept-encoding',
            'authorization',
            'content-type',
            'origin',
            'set-cookie',
            'user-agent',
            'x-csrftoken',
            'x-smp-jwt',
            'x-timestamp',
            'x-requested-with',
        ])
        response['Access-Control-Allow-Methods'] = ', '.join([
            'DELETE',
            'GET',
            'OPTIONS',
            'PATCH',
            'POST',
            'PUT',
        ])
        response['Access-Control-Allow-Origin'] = settings.CORS_ALLOW_ORIGIN
        return response
    return middleware
