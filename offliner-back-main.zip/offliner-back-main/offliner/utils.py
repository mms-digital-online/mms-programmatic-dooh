import datetime
from typing import Union

from offliner.enums import DayTypeEnum


def date_to_day_type(d: Union[datetime.datetime, datetime.date]) -> DayTypeEnum:
    if False:  # TODO check if holiday
        return DayTypeEnum.hol
    else:
        return DayTypeEnum(d.weekday())


def get_all_possible_states_dict(mapping, permissions):
    result = {}
    for final_state_dict in mapping.values():
        result.update({state: [permissions] for state in final_state_dict})
    return result


def alter_state_mapping(target_mapping, source_mapping):
    for initial_state, final_state_dict in source_mapping.items():
        target_mapping.setdefault(initial_state, {})
        for final_state, permissions_list in final_state_dict.items():
            target_mapping[initial_state].setdefault(final_state, [])
            target_mapping[initial_state][final_state].extend(permissions_list)


def date_range(date_from: datetime.date, date_to: datetime.date):
    delta = datetime.timedelta(days=1)
    while date_from <= date_to:
        yield date_from
        date_from += delta
