import json
import os
import shutil
import subprocess
import tempfile
import uuid

from contextlib import ExitStack
from io import BytesIO

from django.conf import settings
from django.core.exceptions import SuspiciousOperation
from django.core.files import File
from django.core.files.base import ContentFile
from PIL import Image, UnidentifiedImageError

from offliner.enums import ExtensionEnum, MimeTypeEnum
from offliner.media.exceptions import MediaProcessError


EXTENSION_TO_MIME = {
    ExtensionEnum.gif: MimeTypeEnum.image,
    ExtensionEnum.jpg: MimeTypeEnum.image,
    ExtensionEnum.jpeg: MimeTypeEnum.image,
    ExtensionEnum.png: MimeTypeEnum.image,
    ExtensionEnum.bmp: MimeTypeEnum.image,

    ExtensionEnum.rmvb: MimeTypeEnum.video,
    ExtensionEnum.mkv: MimeTypeEnum.video,
    ExtensionEnum.wmv: MimeTypeEnum.video,
    ExtensionEnum.mp4: MimeTypeEnum.video,
    ExtensionEnum.avi: MimeTypeEnum.video,
    ExtensionEnum.mov: MimeTypeEnum.video,
    ExtensionEnum.flv: MimeTypeEnum.video,
}


def mime_by_extension(ext: ExtensionEnum) -> MimeTypeEnum:
    return EXTENSION_TO_MIME[ext]


def get_or_create_local_filepath(file_obj, exit_stack):
    """
    Used to send filepath to some subprocess and handle case when file is not local.

    Use with contextlib.ExitStack (contextlib for python2) context object in arg "exit_stack"
    to allow cleanup after exit i.e.:

    >>> from contextlib import ExitStack
    >>> with ExitStack() as exit_stack:
    >>>     tempfile_video_path = get_or_create_local_filepath(file_video, exit_stack)
    """
    try:
        if isinstance(file_obj, File):
            return file_obj.path  # django FileField, with some backend not implementing path
        return file_obj.name
    except (NotImplementedError, SuspiciousOperation, AttributeError):
        file_obj_temp = exit_stack.enter_context(tempfile.NamedTemporaryFile())
        file_obj.seek(0)
        shutil.copyfileobj(file_obj, file_obj_temp)
        file_obj_temp.flush()
        filepath = file_obj_temp.name
        return filepath


def get_video_info_by_fp(fp):
    with ExitStack() as exit_stack:
        source_path = get_or_create_local_filepath(fp, exit_stack)
        return get_video_info(source_path)


def get_video_info(source_path):
    argv = [
        'ffprobe',
        '-i', source_path,
        '-show_entries', 'format=duration,size:stream=width,height,codec_type:stream_tags=rotate',
        '-of', 'json'
    ]
    proc = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = proc.communicate()
    if proc.returncode != 0:
        raise MediaProcessError(err)

    info = json.loads(out)
    duration = float(info['format'].get('duration', 0))
    size = int(info['format'].get('size', 0))

    has_audio = any(s.get('codec_type') == 'audio' for s in info['streams'])

    streams = [s for s in info['streams'] if s.get('width') and s.get('height')]
    width, height = int(streams[0]['width']), int(streams[0]['height'])
    tags = {}
    for s in info['streams']:
        tags.update(s.get('tags', {}))

    if tags.get('rotate') in ('90', '270'):
        width, height = height, width

    return {
        'duration': duration,
        'size': size,
        'width': width,
        'height': height,
        'has_audio': has_audio,
        'tags': tags
    }


def get_image_info_by_fp(fp):
    try:
        img_pil = Image.open(fp)
    except UnidentifiedImageError as e:
        raise MediaProcessError from e
    return {
        'duration': 15.0,
        'width': img_pil.width,
        'height': img_pil.height,
        'tags': {}
    }


def make_image_thumbnail(file_or_path):
    if isinstance(file_or_path, BytesIO):
        file_or_path.seek(0)
    Image.LOAD_TRUNCATED_IMAGES = True
    pil_image = Image.open(file_or_path)

    thumbnail_bounding_box = [
        settings.THUMBNAIL_MAX_WIDTH_PX,
        settings.THUMBNAIL_MAX_HEIGHT_PX,
    ]
    pil_image.thumbnail(thumbnail_bounding_box, Image.ANTIALIAS)

    if pil_image.mode == 'RGBA':
        background_color = (0xff, 0xff, 0xff)
        pil_image_original = pil_image
        pil_image = Image.new('RGB', pil_image.size, background_color)
        pil_image.paste(pil_image_original, mask=pil_image_original)
    elif pil_image.mode == 'P':
        pil_image = pil_image.convert('RGB')

    if pil_image.format == 'JPEG':
        quality = 'keep'
    else:
        quality = 95

    thumbnail = ContentFile(bytes(), name=generate_filename('example.jpg'))
    thumbnail.content_type = 'image/jpeg'
    pil_image.save(thumbnail, format='JPEG', quality=quality, optimize=True)
    thumbnail.seek(0)

    return thumbnail


def get_video_thumbnail_by_fp(fp):
    with ExitStack() as exit_stack:
        source_path = get_or_create_local_filepath(fp, exit_stack)
        return get_video_thumbnail(source_path)


def get_video_thumbnail(source_path):
    result_path = tempfile.NamedTemporaryFile(suffix='.png').name
    argv = [
        'ffmpeg',
        '-i', source_path,
        '-vcodec', 'png', '-vframes', '1', '-an',
        '-f', 'rawvideo', result_path,
    ]
    proc = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = proc.communicate()
    if proc.returncode != 0:
        raise MediaProcessError(err)
    return make_image_thumbnail(result_path)


def generate_filename(old_filename=''):
    ext = ''
    if old_filename:
        _, ext = os.path.splitext(old_filename)
    return str(uuid.uuid4()) + ext
