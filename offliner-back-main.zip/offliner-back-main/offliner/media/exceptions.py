
class MediaProcessError(Exception):
    pass
