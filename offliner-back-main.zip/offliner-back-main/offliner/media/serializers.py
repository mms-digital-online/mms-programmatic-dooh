from datetime import timedelta

from rest_framework import serializers
from rest_framework.exceptions import ParseError, PermissionDenied

from utils.django.models import enum2choices
from utils.django.serializers.fields import ChoiceDisplayField

from offliner.enums import MimeTypeEnum, ExtensionEnum
from offliner.models import Media
from offliner.media.exceptions import MediaProcessError
from offliner.media.utils import (
    mime_by_extension, get_video_info_by_fp, get_image_info_by_fp, make_image_thumbnail, get_video_thumbnail_by_fp,
    generate_filename,
)


class ImageSerializer(serializers.ModelSerializer):
    extension = ChoiceDisplayField(choices=enum2choices(ExtensionEnum))
    mimetype = ChoiceDisplayField(choices=enum2choices(MimeTypeEnum), read_only=True)
    dimensions = serializers.SerializerMethodField()
    duration = serializers.DurationField(write_only=True)
    width = serializers.IntegerField(write_only=True)
    height = serializers.IntegerField(write_only=True)
    visible = serializers.BooleanField(default=True)

    def get_dimensions(self, obj):
        return [obj.width, obj.height]

    def to_internal_value(self, data):
        image_info = get_image_info_by_fp(data['file'])
        data['duration'] = timedelta(seconds=image_info['duration'])
        data['size'] = data['file'].size
        data['width'] = image_info['width']
        data['height'] = image_info['height']
        data['thumb'] = make_image_thumbnail(data['file'].file)
        return super().to_internal_value(data)

    class Meta:
        model = Media
        fields = (
            'id', 'name', 'creator', 'file', 'thumb', 'mimetype', 'extension', 'dimensions', 'size', 'visible',
            'duration', 'width', 'height',
        )


class VideoSerializer(serializers.ModelSerializer):
    extension = ChoiceDisplayField(choices=enum2choices(ExtensionEnum))
    mimetype = ChoiceDisplayField(choices=enum2choices(MimeTypeEnum), read_only=True)
    color_profile = serializers.ReadOnlyField(default='')
    dimensions = serializers.SerializerMethodField()
    duration = serializers.DurationField(write_only=True)
    width = serializers.IntegerField(write_only=True)
    height = serializers.IntegerField(write_only=True)
    visible = serializers.BooleanField(default=True)

    def get_dimensions(self, obj):
        return [obj.width, obj.height, obj.duration]

    def to_internal_value(self, data):
        try:
            video_info = get_video_info_by_fp(data['file'])
        except MediaProcessError:
            raise ParseError({'file': ['Unable to read file']})
        data['duration'] = timedelta(seconds=video_info['duration'])
        data['size'] = data['file'].size
        data['width'] = video_info['width']
        data['height'] = video_info['height']
        data['thumb'] = get_video_thumbnail_by_fp(data['file'].file)
        return super().to_internal_value(data)

    class Meta:
        model = Media
        fields = (
            'id', 'name', 'creator', 'file', 'thumb', 'mimetype', 'extension', 'dimensions', 'color_profile', 'size',
            'visible', 'duration', 'width', 'height',
        )


class MediaSerializer(serializers.ModelSerializer):
    type_to_serializer = {
        MimeTypeEnum.image: ImageSerializer(),
        MimeTypeEnum.video: VideoSerializer(),
    }
    editable_fields = {'visible', 'name'}

    def to_representation(self, instance):
        user = self.context['request'].user
        self._check_ownership_on_view(user, instance)

        mime_type = mime_by_extension(instance.extension)
        return self.type_to_serializer[mime_type].to_representation(instance)

    def validate(self, attrs):
        if self.instance is not None:
            fields_we_cant_edit = ', '.join(set(attrs) - self.editable_fields)
            if fields_we_cant_edit:
                raise PermissionDenied(
                    detail=f'Updating these fields is prohibited: {fields_we_cant_edit}',
                    code='uneditable_field'
                )
        user = self.context['request'].user
        self._check_ownership_on_edit(user, self.instance)
        return super().validate(attrs)

    def to_internal_value(self, data):
        if self.instance is None:
            extension = data['file'].content_type.split('/')[1]
            data['file'].name = generate_filename(data['file'].name)
            data['extension'] = extension
            mime_type = mime_by_extension(ExtensionEnum[extension])
            data = self.type_to_serializer[mime_type].to_internal_value(data)
        return data

    def _check_ownership_on_view(self, user, instance):
        if instance is None:
            return
        elif instance.creator == user:
            return
        elif user.has_perm('offliner.view_all_media'):
            return
        raise PermissionDenied(
            detail='Not enough permissions to see this media',
            code='can_not_see',
        )

    def _check_ownership_on_edit(self, user, instance):
        if instance is None:
            return
        elif instance.creator == user:
            return
        elif user.has_perm('offliner.can_edit_someone_elses_media'):
            return
        raise PermissionDenied(
            detail='Not enough permissions to edit this media',
            code='can_not_edit',
        )

    def create(self, validated_data):
        validated_data['creator'] = self.context['request'].user
        return super().create(validated_data)

    class Meta:
        model = Media
        fields = ('file', )
