from django_filters import rest_framework as filters
from rest_framework import viewsets
from rest_framework.exceptions import ValidationError
from rest_framework.mixins import RetrieveModelMixin, CreateModelMixin, UpdateModelMixin
from rest_framework.permissions import IsAuthenticated

from offliner.enums import MimeTypeEnum
from offliner.models import Media
from offliner.media.serializers import MediaSerializer
from offliner.views import OwnerFilterSetForModelWithCreator, ListModelMixin


class MediaFilterSet(OwnerFilterSetForModelWithCreator):
    search = filters.CharFilter(field_name='name', lookup_expr='icontains')
    mimetype = filters.CharFilter(method='mimetype_filter')
    resolution = filters.CharFilter(field_name='resolution')

    def mimetype_filter(self, queryset, name, value):
        if value:
            try:
                enum_value = MimeTypeEnum[value]
            except KeyError:
                raise ValidationError({'mimetype': ['Incorrect value']})
            queryset = queryset.filter(mimetype=enum_value)
        return queryset

    class Meta:
        model = Media
        fields = ['name', 'extension', 'mimetype', 'resolution', 'owner']


class BaseMediaViewSet(viewsets.GenericViewSet):
    permission_classes = (IsAuthenticated, )
    serializer_class = MediaSerializer
    queryset = Media.objects.select_related(
        'creator'
    ).all().with_mimetype().with_resolution()
    filterset_class = MediaFilterSet


class FilteredMediaViewSet(CreateModelMixin, ListModelMixin, BaseMediaViewSet):
    def get_queryset(self):
        result = super().get_queryset()
        return result.filter(creator=self.request.user)


class UnfilteredMediaViewSet(RetrieveModelMixin, UpdateModelMixin, BaseMediaViewSet):
    pass
