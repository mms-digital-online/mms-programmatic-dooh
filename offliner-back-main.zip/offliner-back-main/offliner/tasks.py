import datetime
import logging

from django.conf import settings
from django.db.models import QuerySet
from django.utils import timezone

from offliner.alg import FillDevicesScheduleAlg
from offliner.celery import task
from offliner.client import DseeClient
from offliner.client import utils as dsee_utils
from offliner.enums import AdCampaignStatusEnum, DeviceTypeEnum
from offliner.models import Device, Media, ArrangedShow, AdCampaign

log = logging.getLogger(__name__)


@task
def sync_all_devices():
    date = timezone.localdate()

    alg = FillDevicesScheduleAlg(date)
    log.debug('starting alg')
    alg.clear_schedule_for_previous_days()
    alg.clear_current_schedule()
    alg.fill_schedule()
    log.debug('schedule created')

    device_type = DeviceTypeEnum.cooler

    files = [m.file for m in Media.get_on_date_for_all_devices(date, device_type=device_type)]

    log.debug('uploading media')
    with DseeClient.get_instance() as client:
        dsee_utils.update_files_in_cloud(client, files)
    log.debug('media uploaded')

    for device_pk in Device.get_all_devices_pks(device_type=device_type):
        sync_device.delay(device_pk)


@task
def sync_device(device_pk):
    device_obj = Device.get_by_pk(device_pk)
    if not device_obj:
        log.error('Device with pk=%s not found', device_pk)
        return

    date = timezone.localdate()
    on_datetime, off_datetime = device_obj.get_working_time_borders(date)
    files = [m.file for m in Media.get_on_date(date, device_pk)]
    sync_restart_needed = False
    with DseeClient.get_instance() as client:
        if not dsee_utils.check_if_device_exists(client, device_obj.external_id):
            log.error(
                'Device with pk=%s and external_id=%s not found in Dsee system',
                device_pk, device_obj.external_id,
            )
            return
        if not dsee_utils.check_if_device_online(client, device_obj.external_id):
            log.warning('Device with pk=%s is offline', device_pk)
            sync_restart_needed = True
        else:
            is_updated = dsee_utils.update_files_on_device(client, files, device_obj.external_id)
            if not is_updated:
                log.warning('Failed to update files on device with pk=%s', device_pk)

            failed_files = dsee_utils.wait_for_files_to_appear_on_device(client, files, device_obj.external_id)
            if failed_files:
                log.warning(
                    'Failed to update these files on device with pk=%s: %s',
                    device_pk, str(failed_files)
                )
                sync_restart_needed = True
    if sync_restart_needed:
        restart_task_at = timezone.localtime() + datetime.timedelta(seconds=settings.DEVICE_SYNC_RETRY_INTERVAL)
        if restart_task_at < off_datetime:
            log.info('Restarting sync of device with pk=%s', device_pk)
            sync_device.apply_async(args=(device_pk,), eta=restart_task_at)
        else:
            log.error('Failed to sync device with pk=%s. Working time ended', device_pk)
    else:
        turn_device_on.apply_async(args=(device_pk, ), eta=on_datetime)
        turn_device_off.apply_async(args=(device_pk, ), eta=off_datetime)
        update_device_playlist.delay(device_pk, 0)


@task
def update_device_playlist(device_pk, offset):

    files_taken = 0
    date = timezone.localdate()
    arranged_shows_queryset = ArrangedShow.get_on_date(date, device_pk)

    # check if we aren't late
    start_datetime = timezone.localtime() + datetime.timedelta(seconds=settings.DSEE_PLAYLIST_SAVE_TIME)
    entries_behind = arranged_shows_queryset.filter(time__lt=start_datetime.time()).count()
    if entries_behind > offset:
        log.warning(
            '%s media are late in time and is not shown on device with pk=%s',
            entries_behind - offset, device_pk,
        )
        offset = entries_behind

    def files_iterator():
        nonlocal files_taken

        arranged_shows = arranged_shows_queryset[offset:]
        if isinstance(arranged_shows, QuerySet):
            arranged_shows = arranged_shows.iterator()

        for arranged_show in arranged_shows:
            yield arranged_show.media.file
            files_taken += 1

    device_obj = Device.get_by_pk(device_pk)
    if not device_obj:
        log.error('Device with pk=%s not found', device_pk)
        return
    on_datetime, off_datetime = device_obj.get_working_time_borders(date)

    with DseeClient.get_instance() as client:
        done = dsee_utils.create_playlist(client, files_iterator(), device_obj.external_id)

    if not files_taken:
        return

    if not done:
        restart_task_at = timezone.localtime() + datetime.timedelta(seconds=settings.DEVICE_SYNC_RETRY_INTERVAL)
        if restart_task_at < off_datetime:
            log.info('Restarting updating of playlist on device with pk=%s', device_pk)
            update_device_playlist.apply_async(args=(device_pk, offset), eta=restart_task_at)
        else:
            log.error('Failed to update playlist on device with pk=%s. Working time ended', device_pk)
    else:
        log.debug(
            'Playlist made for %s files of %s for device pk=%s',
            files_taken, arranged_shows_queryset.count(), device_pk,
        )
        try:
            next_show = arranged_shows_queryset[offset + files_taken]
        except IndexError:
            return
        if not next_show.show_datetime:
            return

        next_start_at = next_show.show_datetime - datetime.timedelta(seconds=settings.DSEE_PLAYLIST_SAVE_TIME)
        update_device_playlist.apply_async(args=(device_pk, offset + files_taken), eta=next_start_at)


@task
def turn_device_on(device_pk):
    device_obj = Device.get_by_pk(device_pk)
    if not device_obj:
        log.error('Device with pk=%s not found', device_pk)
        return

    with DseeClient.get_instance() as client:
        dsee_utils.start_device(client, device_obj.external_id)


@task
def turn_device_off(device_pk):
    device_obj = Device.get_by_pk(device_pk)
    if not device_obj:
        log.error('Device with pk=%s not found', device_pk)
        return

    with DseeClient.get_instance() as client:
        client.stop_device(device_obj.external_id)


@task
def update_campaigns_statuses():
    date = timezone.localdate()

    ad_campaign_qs = AdCampaign.objects.filter(
        status=AdCampaignStatusEnum.active,
        end_at__lt=date,
    )
    ids = tuple(ad_campaign_qs.values_list('id', flat=True))
    if ids:
        ad_campaign_qs.update(status=AdCampaignStatusEnum.completed)
        log.info('Campaigns with those ids switched to completed status: %s', ids)
    else:
        log.info('There are no campaigns to be switched to completed status')
