import datetime

from decimal import Decimal
from itertools import groupby
from operator import itemgetter
from typing import Optional

from django.conf import settings
from django.contrib.auth import get_user_model
from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
from django.db.models import Subquery, OuterRef, Value, Case, When, Q
from django.db.models.functions import Coalesce, Concat, Cast
from django.utils import timezone

from utils.django.models import EnumField

from offliner.enums import (
    DeviceTypeEnum, PlacementEnum, ExtensionEnum, AuctionTypeEnum,
    MediaStatusEnum, DayTypeEnum, AdCampaignStatusEnum,
    MimeTypeEnum,
)
from offliner.media.utils import EXTENSION_TO_MIME
from offliner.utils import date_to_day_type


class DeviceQuerySet(models.QuerySet):

    def with_working_time(self, day_of_week: DayTypeEnum):
        sub_query = DeviceWorkPeriod.objects.filter(
            day_of_week=day_of_week,
            device=OuterRef('pk'),
        )
        return self.annotate(
            turn_on_at=Coalesce(
                Subquery(sub_query.values('turn_on_at')[:1]),
                Value(
                    datetime.time(hour=settings.DEFAULT_DEVICE_TURN_ON_HOUR)
                ),
            ),
            turn_off_at=Coalesce(
                Subquery(sub_query.values('turn_off_at')[:1]),
                Value(
                    datetime.time(hour=settings.DEFAULT_DEVICE_TURN_OFF_HOUR)
                ),
            ),
        )


class DayOfWeekField(models.SmallIntegerField):
    def __init__(self, *args, **kwargs):
        validators = kwargs.get('validators', [])
        validators.append(MinValueValidator(0))
        validators.append(MaxValueValidator(7))
        kwargs['validators'] = validators
        super().__init__(*args, **kwargs)


class AdCampaign(models.Model):
    name = models.CharField(blank=True, max_length=1000)
    creator = models.ForeignKey(get_user_model(), null=True, on_delete=models.SET_NULL)

    budget = models.DecimalField(
        verbose_name='Overall budget in Rub', default=0, decimal_places=2, max_digits=12,
    )
    day_limit = models.DecimalField(
        verbose_name='Budget for day in Rub', default=0, decimal_places=2, max_digits=12,
    )
    auction_type = EnumField(
        enum_class=AuctionTypeEnum,
        default=AuctionTypeEnum.ppv,
    )
    status = EnumField(
        enum_class=AdCampaignStatusEnum,
        default=AdCampaignStatusEnum.draft,
    )

    total_shows = models.IntegerField(validators=[MinValueValidator(1)], default=0)

    start_at = models.DateField()
    end_at = models.DateField()

    visible = models.BooleanField(default=True)

    approval = models.BooleanField(default=False)
    higher_approval = models.BooleanField(default=False)

    comment = models.TextField(blank=True)

    @property
    def period(self):
        return self.start_at, self.end_at

    @property
    def schedule(self):
        """
        Get media show schedule in this format:
            {
                "mon": [
                    ["12:00:00", "14:00:00"],
                    ["17:00:00", "22:00:00"]
                ],
                "hol": [
                    ["00:00:00", "23:59:59"]
                ]
            }
        """
        result = {}
        data = self.floatingshow_set.all().values_list(
            'day_of_week', 'start_at', 'end_at'
        ).order_by(
            'day_of_week'
        )
        data_by_day_of_week = {
            k: list(v) for k, v in groupby(data, itemgetter(0))
        }
        for day in DayTypeEnum:
            result[day.name] = [
                [str(row[1]), str(row[2])]
                for row in data_by_day_of_week.get(day, ())
            ]
        return result

    @property
    def shows(self):
        now = timezone.localtime()
        return self.get_arranged_shows(is_final=True, on_datetime=now).count()

    @classmethod
    def get_ready_to_show_on_date(cls, date):
        return cls.objects.filter(
            start_at__lte=date,
            end_at__gte=date,
            approval=True,
            higher_approval=True,
            visible=True,
            status=AdCampaignStatusEnum.active,
        )

    @classmethod
    def get_for_draft_schedule_on_date(cls, date):
        return cls.objects.filter(
            start_at__lte=date,
            end_at__gte=date,
            visible=True,
        )

    def get_already_made_shows(self, is_final=True):
        return self.get_arranged_shows(is_final=is_final).count()

    def get_total_spent(self, is_final=True) -> Decimal:
        # TODO optimize it
        total_spent = Decimal()
        for show in self.get_arranged_shows(is_final=is_final).select_related('device'):
            total_spent += show.device.get_price_per_show(show.show_datetime)
        return total_spent

    def get_budget_on_day(self, is_final=True):
        total_spent = self.get_total_spent(is_final)
        left = self.budget - total_spent
        return min(left, self.day_limit)

    def get_arranged_shows(self, is_final=True, on_datetime=None):
        result = self.arrangedshow_set.filter(
            is_final=is_final,
            date__gte=self.start_at,
            date__lte=self.end_at,
        )
        if on_datetime is not None:
            result = result.filter(
                Q(date=on_datetime.date(), time__lte=on_datetime.time()) | Q(date__lt=on_datetime.date()),
            )
        return result

    class Meta:
        permissions = (
            ('can_change_client', 'Can change client'),
            ('can_make_invisible', 'Can make invisible'),
            ('can_approve', 'Can approve'),
            ('can_higher_approve', 'Can higher approve'),
            ('create_in_any_status', 'Can create in any status'),
            ('can_add_someone_elses_adcampaign', 'Can add someone else`s adcampaign'),
            ('can_edit_someone_elses_adcampaign', 'Can edit someone else`s adcampaign'),
            ('can_delete_someone_elses_adcampaign', 'Can delete someone else`s adcampaign'),
            ('view_all_adcampaigns', 'Can see list of all ad campaigns'),
        )


class FloatingShow(models.Model):
    ad_campaign = models.ForeignKey('AdCampaign', on_delete=models.CASCADE)

    day_of_week = EnumField(enum_class=DayTypeEnum)

    start_at = models.TimeField(default=datetime.time(hour=7))
    end_at = models.TimeField(default=datetime.time(hour=22))


class Device(models.Model):
    name = models.TextField(blank=True)
    description = models.TextField(blank=True)

    location = models.ForeignKey('Location', on_delete=models.PROTECT)

    sn = models.CharField(max_length=255, null=True, blank=True)
    password = models.CharField(max_length=255, null=True, blank=True)

    external_id = models.CharField(max_length=255)

    media_switch_delay = models.DurationField(default='00:00:01')

    width = models.SmallIntegerField()
    height = models.SmallIntegerField()

    type = EnumField(enum_class=DeviceTypeEnum)
    ots = models.FloatField(null=True)
    grp = models.FloatField(null=True)

    objects = DeviceQuerySet.as_manager()

    @classmethod
    def get_all_devices_pks(cls, device_type: Optional[DeviceTypeEnum] = None):
        queryset = cls.objects.all()
        if device_type is not None:
            queryset = queryset.filter(type=device_type)
        return queryset.values_list('pk', flat=True)

    @classmethod
    def get_by_pk(cls, pk):
        return cls.objects.filter(pk=pk).first()

    @property
    def resolution(self):
        return self.width, self.height

    def get_working_time_borders(self, date):
        schedule = DeviceWorkPeriod.get_by_date(self.pk, date)
        if schedule:
            turn_on_at = schedule.turn_on_at
            turn_off_at = schedule.turn_off_at
        else:
            turn_on_at = datetime.time(hour=settings.DEFAULT_DEVICE_TURN_ON_HOUR)
            turn_off_at = datetime.time(hour=settings.DEFAULT_DEVICE_TURN_OFF_HOUR)

        border_1 = timezone.get_current_timezone().localize(datetime.datetime.combine(date, turn_on_at))
        border_2 = timezone.get_current_timezone().localize(datetime.datetime.combine(date, turn_off_at))

        return border_1, border_2

    def get_price_per_show(self, on_datetime=None):
        # TODO make it different for different device types
        return settings.PRICE_PER_SHOW


class DeviceWorkPeriod(models.Model):
    device = models.ForeignKey('Device', on_delete=models.CASCADE)
    day_of_week = EnumField(enum_class=DayTypeEnum)
    turn_on_at = models.TimeField(default=datetime.time(hour=settings.DEFAULT_DEVICE_TURN_ON_HOUR))
    turn_off_at = models.TimeField(default=datetime.time(hour=settings.DEFAULT_DEVICE_TURN_OFF_HOUR))

    @classmethod
    def get_by_date(cls, device_id: int, date: datetime.date):
        return cls.objects.filter(
            device_id=device_id,
            day_of_week=date_to_day_type(date),
        ).first()

    class Meta:
        unique_together = ('device', 'day_of_week')


class Location(models.Model):
    name = models.CharField(max_length=255)
    lat = models.DecimalField(max_digits=9, decimal_places=6)
    lon = models.DecimalField(max_digits=9, decimal_places=6)
    placement = EnumField(enum_class=PlacementEnum)
    address = models.TextField(blank=True)

    @property
    def geo(self):
        return self.lat, self.lon


class ArrangedShow(models.Model):
    device = models.ForeignKey('Device', on_delete=models.PROTECT)
    media = models.ForeignKey('Media', on_delete=models.PROTECT)
    ad_campaign = models.ForeignKey('AdCampaign', on_delete=models.CASCADE, blank=True, null=True)
    date = models.DateField()
    index = models.IntegerField()
    time = models.TimeField(null=True)
    is_final = models.BooleanField(verbose_name='Entry is not for draft schedule', default=True)

    @property
    def show_datetime(self) -> Optional[datetime.datetime]:
        if self.time:
            return timezone.get_current_timezone().localize(
                datetime.datetime.combine(self.date, self.time)
            )
        return None

    @classmethod
    def get_on_date(cls, date: datetime.date, device_id: int):
        return ArrangedShow.objects.filter(
            date=date,
            device=device_id,
            is_final=True,
        ).order_by(
            'index'
        ).select_related(
            'media'
        )


class MediaQuerySet(models.QuerySet):

    def with_mimetype(self):
        cases = [When(extension=e, then=m) for e, m in EXTENSION_TO_MIME.items()]
        return self.annotate(
            mimetype=Case(
                *cases,
                output_field=EnumField(enum_class=MimeTypeEnum)
            )
        )

    def with_resolution(self):
        return self.annotate(
            resolution=Concat(
                Cast('width', output_field=models.CharField()),
                Value('x'),
                Cast('height', output_field=models.CharField()),
            ),
        )


class Media(models.Model):
    name = models.CharField(blank=True, max_length=1000)
    creator = models.ForeignKey(get_user_model(), null=True, on_delete=models.SET_NULL)

    file = models.FileField()
    thumb = models.FileField(null=True)
    duration = models.DurationField()

    width = models.SmallIntegerField()
    height = models.SmallIntegerField()
    extension = EnumField(enum_class=ExtensionEnum)
    size = models.IntegerField()

    visible = models.BooleanField(default=True)

    objects = MediaQuerySet.as_manager()

    @classmethod
    def get_on_date_for_all_devices(cls, date: datetime.date, device_type: Optional[DeviceTypeEnum] = None):
        arranged_show_queryset = ArrangedShow.objects.filter(
            date=date,
            is_final=True,
        )
        if device_type is not None:
            arranged_show_queryset = arranged_show_queryset.filter(
                device__type=device_type,
            )
        return cls.objects.filter(
            pk__in=arranged_show_queryset.values_list(
                'media', flat=True,
            ),
        )

    @classmethod
    def get_on_date(cls, date: datetime.date, device_id: int):
        show_objects_filter = ArrangedShow.objects.filter(
            date=date,
            device=device_id,
            is_final=True,
        )
        return cls.objects.filter(
            pk__in=show_objects_filter.values_list(
                'media', flat=True,
            )
        )

    class Meta:
        permissions = (
            ('view_all_media', 'Can see list of all media'),
            ('can_edit_someone_elses_media', 'Can edit someone else`s media'),
        )


class Placeholder(models.Model):
    media = models.ForeignKey('Media', on_delete=models.PROTECT)
    priority = models.IntegerField()


class OrderedMediaForDevice(models.Model):
    device = models.ForeignKey('Device', on_delete=models.PROTECT)
    media = models.ForeignKey('Media', on_delete=models.PROTECT)
    ad_campaign = models.ForeignKey('AdCampaign', on_delete=models.CASCADE)
    status = EnumField(enum_class=MediaStatusEnum)

    @property
    def shows(self):
        now = timezone.localtime()
        return self.ad_campaign.get_arranged_shows(is_final=True, on_datetime=now).filter(
            device_id=self.device_id,
            media_id=self.media_id,
        ).count()

    class Meta:
        unique_together = ('device', 'media', 'ad_campaign')
