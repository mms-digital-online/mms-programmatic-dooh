from utils.log_config import LoggingConfig


class OfflinerLoggingConfig(LoggingConfig):

    def __init__(self):
        self.base_config['formatters']['dev']['format'] = '[%(asctime)s] %(name)s %(levelname)s %(message)s'
        super().__init__()
