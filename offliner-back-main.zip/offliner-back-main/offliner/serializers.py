import itertools

from datetime import timedelta
from distutils.util import strtobool

from django.conf import settings
from django.db import transaction
from rest_framework import serializers
from rest_framework.exceptions import ValidationError, PermissionDenied
from rest_framework.serializers import ListSerializer

from offliner.alg import FillDevicesScheduleAlg
from utils.django.models import enum2choices
from utils.django.serializers.fields import ChoiceDisplayField

from offliner.enums import (
    PlacementEnum, DeviceTypeEnum, DayTypeEnum, AdCampaignStatusEnum, MediaStatusEnum, AuctionTypeEnum,
)
from offliner.models import AdCampaign, OrderedMediaForDevice, FloatingShow, Device, Location
from offliner.utils import get_all_possible_states_dict, alter_state_mapping


NO_VALUE = None
ANY_VALUE = 'any value'


# structure format by levels:
# <status>, <has approval>, <has higher approval>
#     <new status>, <will have approval>, <will have higher approval>
#         <list of variants of <tuple of required permissions> >
AD_CAMPAIGN_STATE_CHANGE_MAP_BY_USER_PERMISSION = {

    # ad campaign creation

    (NO_VALUE, NO_VALUE, NO_VALUE): {
        (AdCampaignStatusEnum.draft, False, False): [('add_adcampaign', ), ],
        (AdCampaignStatusEnum.moderation, False, False): [('add_adcampaign', ), ],
        (AdCampaignStatusEnum.start_when_ready, False, False): [('add_adcampaign', ), ],
    },

    # ad campaign edit

    (AdCampaignStatusEnum.draft, False, False): {
        (AdCampaignStatusEnum.moderation, False, False): [('change_adcampaign', ), ],
        (AdCampaignStatusEnum.start_when_ready, False, False): [('change_adcampaign', ), ],
    },
    (AdCampaignStatusEnum.start_when_ready, False, False): {
        (AdCampaignStatusEnum.moderation, False, False): [('change_adcampaign', ), ],
        (AdCampaignStatusEnum.draft, False, False): [('change_adcampaign', ), ],
    },
    (AdCampaignStatusEnum.moderation, False, False): {
        (AdCampaignStatusEnum.draft, False, False): [('change_adcampaign', ), ],
        (AdCampaignStatusEnum.start_when_ready, False, False): [('change_adcampaign', ), ],
        (AdCampaignStatusEnum.moderation, True, False): [('change_adcampaign', 'can_approve'), ],
        (AdCampaignStatusEnum.rejected, False, False): [('change_adcampaign', 'can_approve'), ],
    },
    (AdCampaignStatusEnum.moderation, True, False): {
        (AdCampaignStatusEnum.stopped, True, True): [('change_adcampaign', 'can_approve', 'can_higher_approve'), ],
        (AdCampaignStatusEnum.active, True, True): [('change_adcampaign', 'can_approve', 'can_higher_approve'), ],
        (AdCampaignStatusEnum.rejected, False, False): [('change_adcampaign', 'can_approve'), ],
        (AdCampaignStatusEnum.moderation, False, False): [('change_adcampaign', 'can_approve'), ],
    },
    (AdCampaignStatusEnum.active, True, True): {
        (AdCampaignStatusEnum.draft, True, True): [('change_adcampaign', ), ],
        (AdCampaignStatusEnum.completed, True, True): [('change_adcampaign', ), ],
        (AdCampaignStatusEnum.stopped, True, True): [('change_adcampaign', ), ],
        (AdCampaignStatusEnum.moderation, False, False): [('change_adcampaign', 'can_approve'), ],
        (AdCampaignStatusEnum.rejected, False, False): [('change_adcampaign', 'can_approve'), ],
    },
    (AdCampaignStatusEnum.draft, True, True): {
        (AdCampaignStatusEnum.active, True, True): [('change_adcampaign', ), ],
        (AdCampaignStatusEnum.completed, True, True): [('change_adcampaign', ), ],
        (AdCampaignStatusEnum.stopped, True, True): [('change_adcampaign', ), ],
        (AdCampaignStatusEnum.moderation, False, False): [('change_adcampaign', 'can_approve'), ],
        (AdCampaignStatusEnum.rejected, False, False): [('change_adcampaign', 'can_approve'), ],
    },
    (AdCampaignStatusEnum.completed, True, True): {
        (AdCampaignStatusEnum.active, True, True): [('change_adcampaign', ), ],
        (AdCampaignStatusEnum.draft, True, True): [('change_adcampaign', ), ],
        (AdCampaignStatusEnum.stopped, True, True): [('change_adcampaign', ), ],
        (AdCampaignStatusEnum.moderation, False, False): [('change_adcampaign', 'can_approve'), ],
        (AdCampaignStatusEnum.rejected, False, False): [('change_adcampaign', 'can_approve'), ],
    },
    (AdCampaignStatusEnum.stopped, True, True): {
        (AdCampaignStatusEnum.active, True, True): [('change_adcampaign', ), ],
        (AdCampaignStatusEnum.draft, True, True): [('change_adcampaign', ), ],
        (AdCampaignStatusEnum.completed, True, True): [('change_adcampaign', ), ],
        (AdCampaignStatusEnum.moderation, False, False): [('change_adcampaign', 'can_approve'), ],
        (AdCampaignStatusEnum.rejected, False, False): [('change_adcampaign', 'can_approve'), ],
    },
}

alter_state_mapping(
    AD_CAMPAIGN_STATE_CHANGE_MAP_BY_USER_PERMISSION,
    {
        # rules for admin to create ad campaign in any state
        (NO_VALUE, NO_VALUE, NO_VALUE): get_all_possible_states_dict(
            AD_CAMPAIGN_STATE_CHANGE_MAP_BY_USER_PERMISSION,
            ('add_adcampaign', 'create_in_any_status'),
        ),

        # rules for admin to edit ad campaign to any state
        (ANY_VALUE, ANY_VALUE, ANY_VALUE): get_all_possible_states_dict(
            AD_CAMPAIGN_STATE_CHANGE_MAP_BY_USER_PERMISSION,
            ('change_adcampaign', 'create_in_any_status'),
        )
    }
)


class CustomListSerializer(ListSerializer):
    def validate_request(self, request):
        self.child.validate_request(request)


class DeviceSerializer(serializers.ModelSerializer):

    resolution = serializers.ListField(child=serializers.IntegerField())
    placement = ChoiceDisplayField(
        choices=enum2choices(PlacementEnum), source='location.placement',
    )
    type = ChoiceDisplayField(choices=enum2choices(DeviceTypeEnum))
    geo = serializers.ListField(
        child=serializers.DecimalField(max_digits=9, decimal_places=6),
        source='location.geo',
    )
    address = serializers.CharField(source='location.address', required=False, default='')

    def to_internal_value(self, data):
        data.setdefault('media_switch_delay', timedelta(seconds=1))
        ret = super().to_internal_value(data)
        if 'resolution' in ret:
            ret['width'], ret['height'] = ret.pop('resolution')

        # FIXME make these fields required to fill
        ret.setdefault('sn', '123')
        ret.setdefault('password', '123')
        return ret

    def validate_request(self, request):
        short_info_value = request.query_params.get('short_info', '0')
        try:
            strtobool(short_info_value)
        except ValueError:
            raise ValidationError({'short_info': ['Wrong value']})

    @property
    def _readable_fields(self):
        short_info_fields = {'id', 'geo'}
        short_info_value = self.context['request'].query_params.get('short_info', '0')
        try:
            short_info_value = strtobool(short_info_value)
        except ValueError:
            short_info_value = False
        for field in super()._readable_fields:
            if short_info_value and field.field_name not in short_info_fields:
                continue
            yield field

    def update_location(self, data_dict):
        location_data = data_dict.pop('location', None)
        if location_data is not None:
            data_dict['location'], _ = Location.objects.get_or_create(
                name='some name',  # FIXME
                lat=location_data['geo'][0],
                lon=location_data['geo'][1],
                placement=location_data['placement'],
                address=location_data.get('address', ''),
            )

    def create(self, validated_data):
        self.update_location(validated_data)
        instance = super().create(validated_data)
        return instance

    def update(self, instance, validated_data):
        self.update_location(validated_data)
        instance = super().update(instance, validated_data)
        return instance

    class Meta:
        model = Device
        fields = (
            'id', 'name', 'description', 'resolution', 'placement', 'type', 'geo', 'address',
            'external_id', 'media_switch_delay', 'ots', 'grp',
        )
        list_serializer_class = CustomListSerializer


class MediaContainerSerializer(serializers.ModelSerializer):
    device_id = serializers.IntegerField()
    media_id = serializers.IntegerField()
    status = ChoiceDisplayField(choices=enum2choices(MediaStatusEnum))
    shows = serializers.IntegerField(read_only=True)

    class Meta:
        model = OrderedMediaForDevice
        fields = ('device_id', 'media_id', 'status', 'shows')


class AdCampaignSerializer(serializers.ModelSerializer):

    media_containers = serializers.ListField(
        child=MediaContainerSerializer(),
        source='orderedmediafordevice_set.all'
    )
    schedule = serializers.JSONField()
    period = serializers.ListField(child=serializers.DateField())
    status = ChoiceDisplayField(choices=enum2choices(AdCampaignStatusEnum))
    auction_type = ChoiceDisplayField(choices=enum2choices(AuctionTypeEnum))
    start_at = serializers.DateField(write_only=True, required=False)
    end_at = serializers.DateField(write_only=True, required=False)
    shows = serializers.IntegerField(read_only=True)

    def update_media_containers(self, instance, media_containers_data):
        if media_containers_data is None:
            return
        media_containers_objs = (OrderedMediaForDevice(**attrs) for attrs in media_containers_data['all'])
        instance.orderedmediafordevice_set.all().delete()
        instance.orderedmediafordevice_set.set(media_containers_objs, bulk=False)

    def update_schedule(self, instance, schedule_data):
        if schedule_data is None:
            return
        schedule_objs = []
        for week_day, items in schedule_data.items():
            for start_at, end_at in items:
                try:
                    day_of_week = DayTypeEnum[week_day]
                except KeyError:
                    raise ValidationError({'schedule': [f'{week_day} is not supported week day option']})

                schedule_objs.append(FloatingShow(start_at=start_at, end_at=end_at, day_of_week=day_of_week))

        instance.floatingshow_set.all().delete()
        instance.floatingshow_set.set(schedule_objs, bulk=False)

    def _check_state_change(self, user, instance, new_values):
        if all(
                n not in new_values or new_values[n] == getattr(instance, n, None)
                for n in ('status', 'approval', 'higher_approval')
        ):
            return

        def get_val(d, k1, k2, k3):
            result = []
            variants = itertools.product((k1, ANY_VALUE), (k2, ANY_VALUE), (k3, ANY_VALUE))
            for variant in variants:
                if variant in d:
                    result.append(d[variant])
            return result

        new_state_dict_variants = get_val(
            AD_CAMPAIGN_STATE_CHANGE_MAP_BY_USER_PERMISSION,
            getattr(instance, 'status', None),
            getattr(instance, 'approval', None),
            getattr(instance, 'higher_approval', None),
        )
        for new_state_dict in new_state_dict_variants:
            required_permissions_variants = get_val(
                new_state_dict,
                new_values.get('status', getattr(instance, 'status', None)),
                new_values.get('approval', getattr(instance, 'approval', None)),
                new_values.get('higher_approval', getattr(instance, 'higher_approval', None)),
            )
            for required_permissions in required_permissions_variants:
                for permissions_variants in required_permissions:
                    if all(user.has_perm(f'offliner.{permission}') for permission in permissions_variants):
                        return
        raise PermissionDenied(
            detail='Unsupported action on ad campaign',
            code='can_not_set_state',
        )

    def _check_visibility_change(self, user, instance, new_values):
        if instance is None or 'visible' not in new_values:
            return
        elif instance.visible == new_values['visible']:
            return
        elif user.has_perm('offliner.can_make_invisible'):
            return
        raise PermissionDenied(
            detail='Not enough permissions to change ad campaign visibility',
            code='can_not_set_visible',
        )

    def _check_creator_change(self, user, instance, new_values):
        if instance is None or 'creator' not in new_values:
            return
        elif instance.creator == new_values['creator']:
            return
        elif user.has_perm('offliner.can_change_client'):
            return
        raise PermissionDenied(
            detail='Not enough permissions to change ad campaign client',
            code='can_not_change_client',
        )

    def _check_ownership(self, user, instance):
        if instance is None:
            return
        elif instance.creator == user:
            return
        elif user.has_perm('offliner.view_all_adcampaigns'):
            return
        raise PermissionDenied(
            detail='Not enough permissions to see this ad campaign',
            code='can_not_see',
        )

    def _check_permissions(self, user, instance, new_values):
        if instance is None:
            return
        elif instance.creator_id == user.id:
            return
        elif (
                user.has_perm('offliner.can_edit_someone_elses_adcampaign') or
                set(new_values).issubset({'status', 'approval', 'higher_approval'})
        ):
            return
        raise PermissionDenied(
            detail='Can not edit ad campaign that belong to someone else',
            code='can_not_edit',
        )

    def to_internal_value(self, data):
        ret = super().to_internal_value(data)
        if 'period' in ret:
            ret['start_at'], ret['end_at'] = ret.pop('period')
        return ret

    def to_representation(self, instance):
        user = self.context['request'].user

        self._check_ownership(user, instance)

        return super().to_representation(instance)

    def validate(self, attrs):
        user = self.context['request'].user

        self._check_creator_change(user, self.instance, attrs)
        self._check_visibility_change(user, self.instance, attrs)
        self._check_permissions(user, self.instance, attrs)
        self._check_state_change(user, self.instance, attrs)

        return super().validate(attrs)

    def create(self, validated_data):
        media_containers_data = validated_data.pop('orderedmediafordevice_set', None)
        schedule_data = validated_data.pop('schedule', None)

        validated_data['creator'] = self.context['request'].user
        instance = super().create(validated_data)

        self.update_media_containers(instance, media_containers_data)
        self.update_schedule(instance, schedule_data)

        return instance

    def update(self, instance, validated_data):
        media_containers_data = validated_data.pop('orderedmediafordevice_set', None)
        schedule_data = validated_data.pop('schedule', None)
        instance = super().update(instance, validated_data)
        self.update_media_containers(instance, media_containers_data)
        self.update_schedule(instance, schedule_data)
        return instance

    def save(self, **kwargs):
        with transaction.atomic():
            instance = super().save(**kwargs)
            new_data = dict(self.validated_data)
            new_data.update(kwargs)
            if (
                    settings.AD_CAMPAIGN_PRE_SAVE_CHECKS_FOR_DEVICE_OVERLOAD and
                    FillDevicesScheduleAlg.is_check_needed(instance, new_data)
            ):
                if not FillDevicesScheduleAlg.check_for_overload(instance):
                    raise ValidationError(
                        detail='Devices are overloaded. You should probably add a few days or reduce a budget',
                        code='devices_overload',
                    )
                if not instance.get_already_made_shows(is_final=False):
                    raise ValidationError(
                        detail='Number of shows turned out to be zero. Budget is too low probably',
                        code='zero_shows',
                    )
        return instance

    class Meta:
        model = AdCampaign
        fields = (
            'id', 'creator', 'media_containers', 'schedule', 'end_at', 'start_at', 'period', 'status',
            'auction_type', 'name', 'budget', 'day_limit', 'visible', 'approval', 'higher_approval', 'comment',
            'shows',
        )
