import enum

from django.contrib.auth.models import Group
from django.db.models import Q, Value
from django.db.models.functions import Concat
from django_filters import rest_framework as filters
from django.contrib.auth import get_user_model
from rest_framework import viewsets
from rest_framework.mixins import DestroyModelMixin, UpdateModelMixin, CreateModelMixin, RetrieveModelMixin
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from utils.django.filters import FilterSet

from offliner.enums import AdCampaignStatusEnum
from offliner.media.serializers import MediaSerializer
from offliner.media.views import MediaFilterSet
from offliner.models import AdCampaign, Device, Media
from offliner.serializers import DeviceSerializer, AdCampaignSerializer, AD_CAMPAIGN_STATE_CHANGE_MAP_BY_USER_PERMISSION
from offliner.users.models import UserToManagerLink
from offliner.users.permissions import (
    HasAccessToAdministrationPage, DjangoModelPermissions, CanViewAllAdCampaigns, CanViewAllMedia,
)
from offliner.users.serializers import (
    UserSerializer, GroupSerializer, UserToManagerLinkSerializer, UpdateUserSerializer,
)
from offliner.views import (
    AdCampaignFilterSet, BaseOwnerFilterSet,
    ListModelMixin,
)


class BaseAdminAdCampaignsViewSet(viewsets.GenericViewSet):
    permission_classes = (IsAuthenticated, HasAccessToAdministrationPage, DjangoModelPermissions, CanViewAllAdCampaigns)
    serializer_class = AdCampaignSerializer
    queryset = AdCampaign.objects.prefetch_related('orderedmediafordevice_set').all()
    filterset_class = AdCampaignFilterSet

    def get_queryset(self):
        result = super().get_queryset()
        if not self.request.user.has_perm('offliner.can_edit_someone_elses_adcampaign'):
            result = result.exclude(status=AdCampaignStatusEnum.draft)
        return result


class AdminAllAdCampaignsViewSet(
        ListModelMixin,
        DestroyModelMixin,
        BaseAdminAdCampaignsViewSet
):
    pass


class AdminUserAdCampaignsViewSetAdmin(ListModelMixin, BaseAdminAdCampaignsViewSet):
    def get_queryset(self):
        result = super().get_queryset()
        return result.filter(
            creator=self.kwargs.get('user_id'),
        )


class UserFilterSet(BaseOwnerFilterSet):
    search = filters.CharFilter(method='search_for_users')
    moderation = filters.BooleanFilter(method='with_ad_campaigns_on_moderation')

    user_lookup = 'pk'
    manager_lookup = 'managed_by'

    def search_for_users(self, queryset, name, value):
        if value:
            queryset = queryset.annotate(
                full_name=Concat('first_name', Value(' '), 'last_name'),
            ).filter(
                Q(email__icontains=value) | Q(id__icontains=value) | Q(full_name__icontains=value),
            )
        return queryset

    def with_ad_campaigns_on_moderation(self, queryset, name, value):
        if value:
            queryset = queryset.filter(
                pk__in=AdCampaign.objects.filter(
                    status=AdCampaignStatusEnum.moderation
                ).values_list(
                    'creator', flat=True
                ),
            )
        return queryset

    class Meta:
        model = get_user_model()
        fields = ['search', 'moderation', 'owner']


class AdminUsersViewSet(
        RetrieveModelMixin,
        ListModelMixin,
        CreateModelMixin,
        UpdateModelMixin,
        DestroyModelMixin,
        viewsets.GenericViewSet,
):
    permission_classes = (IsAuthenticated, HasAccessToAdministrationPage, DjangoModelPermissions)
    serializer_class = UserSerializer
    queryset = get_user_model().objects.all()
    filterset_class = UserFilterSet

    def get_serializer_class(self):
        serializer_class = self.serializer_class

        if self.request.method in ('PUT', 'PATCH'):
            serializer_class = UpdateUserSerializer

        return serializer_class


class AdminDeviceViewSet(
        CreateModelMixin,
        UpdateModelMixin,
        DestroyModelMixin,
        viewsets.GenericViewSet,
):
    permission_classes = (IsAuthenticated, HasAccessToAdministrationPage, DjangoModelPermissions)
    serializer_class = DeviceSerializer
    queryset = Device.objects.select_related('location').all()


class AdminGroupViewSet(
        RetrieveModelMixin,
        ListModelMixin,
        CreateModelMixin,
        UpdateModelMixin,
        DestroyModelMixin,
        viewsets.GenericViewSet,
):
    permission_classes = (IsAuthenticated, HasAccessToAdministrationPage, DjangoModelPermissions)
    serializer_class = GroupSerializer
    queryset = Group.objects.all()


class UserToManagerLinkFilterSet(FilterSet):
    class Meta:
        model = UserToManagerLink
        fields = ('user', 'manager')


class AdminUserToManagerLinkViewSet(
        RetrieveModelMixin,
        ListModelMixin,
        CreateModelMixin,
        DestroyModelMixin,
        viewsets.GenericViewSet,
):
    permission_classes = (IsAuthenticated, HasAccessToAdministrationPage, DjangoModelPermissions)
    serializer_class = UserToManagerLinkSerializer
    queryset = UserToManagerLink.objects.all()
    filterset_class = UserToManagerLinkFilterSet


class BaseAdminUserMediaViewSet(viewsets.GenericViewSet):
    permission_classes = (IsAuthenticated, HasAccessToAdministrationPage, DjangoModelPermissions, CanViewAllMedia)
    serializer_class = MediaSerializer
    queryset = Media.objects.all().with_mimetype().with_resolution()
    filterset_class = MediaFilterSet


class AdminUserMediaViewSet(ListModelMixin, BaseAdminUserMediaViewSet):

    def get_queryset(self):
        result = super().get_queryset()
        return result.filter(
            creator=self.kwargs.get('user_id'),
        )


class AdminMediaViewSet(ListModelMixin, DestroyModelMixin, BaseAdminUserMediaViewSet):
    pass


class AdminAdCampaignStates(APIView):
    permission_classes = (IsAuthenticated, HasAccessToAdministrationPage)

    def get(self, request):
        def _to_str(state):
            result = []
            for v in state:
                if isinstance(v, enum.Enum):
                    result.append(v.name)
                elif v is None:
                    result.append('no value')
                else:
                    result.append(str(v).lower())
            return ', '.join(result)
        row_pattern = '(%s) -> (%s) : (%s)'
        result = [
            row_pattern % (
                '<status>, <has approval>, <has higher approval>',
                '<new status>, <will have approval>, <will have higher approval>',
                '<list of required permissions>',
            )
        ]

        for initial_state, further_states in AD_CAMPAIGN_STATE_CHANGE_MAP_BY_USER_PERMISSION.items():
            for further_state, permission_variants in further_states.items():
                for permissions in permission_variants:
                    result.append(
                        row_pattern % (
                            _to_str(initial_state),
                            _to_str(further_state),
                            _to_str(permissions),
                        )
                    )
        return Response(result)
