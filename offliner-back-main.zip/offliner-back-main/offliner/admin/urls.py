from django.urls import path

from utils.django.routers import Router

from offliner.admin import views


router = Router()

router.register(r'users/(?P<user_id>\d+)/campaigns', views.AdminUserAdCampaignsViewSetAdmin)
router.register('campaigns', views.AdminAllAdCampaignsViewSet)
router.register('users', views.AdminUsersViewSet)
router.register('devices', views.AdminDeviceViewSet)
router.register('roles', views.AdminGroupViewSet)
router.register('personal_management', views.AdminUserToManagerLinkViewSet)
router.register(r'users/(?P<user_id>\d+)/media', views.AdminUserMediaViewSet)
router.register(r'media', views.AdminMediaViewSet)

urlpatterns = [
    path('campaigns/states', views.AdminAdCampaignStates.as_view()),
] + router.urls
