from utils.django.commands.celery import Command as BaseCommand


class Command(BaseCommand):
    def get_celery_module_name(self):
        return 'offliner.celery'
