from django.core.management.base import BaseCommand

from offliner.celery import app


class Command(BaseCommand):
    help = 'Revoke all celery tasks'

    def handle(self, *args, **options):
        def revoke_tasks(hosts_data):
            if not hosts_data:
                return
            for host_data in hosts_data.values():
                for task_data in host_data:
                    if 'request' in task_data:
                        task_id = task_data['request'].get('id')
                    else:
                        task_id = task_data.get('id')
                    if task_id:
                        print(f'Revoking task with id={task_id}')
                        c.revoke(task_id, terminate=True)

        c = app.control
        i = c.inspect()
        revoke_tasks(i.reserved())
        revoke_tasks(i.scheduled())
        revoke_tasks(i.active())
        print('Done')
