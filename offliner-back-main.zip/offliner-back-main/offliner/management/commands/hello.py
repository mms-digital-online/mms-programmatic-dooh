import os
import logging

from django.core.management.base import BaseCommand

from offliner.client import DseeClient

log = logging.getLogger(__name__)


TEST_PLAYLIST_NAME = 'auto_added_playlist.txt'


class Command(BaseCommand):
    help = 'Hello World'

    def handle(self, *args, **options):

        with DseeClient.get_instance() as client:
            self.do_stuff(client)

    def do_stuff(self, client):
        devices_list_data = client.devices_list()
        print('devices_list', devices_list_data)
        device_id = devices_list_data[0]['id']
        print('device_info', client.device_info(device_id))

        print('run_device', client.run_device(device_id))

        file_path = os.getenv('TEST_VIDEO_PATH')
        file_name = os.path.split(file_path)[1]

        cloud_file_list = client.cloud_files()
        print('cloud_files', cloud_file_list)
        file_ids_to_delete = [
            x['id'] for x in cloud_file_list
            if x['name'] == file_name
        ]
        if file_ids_to_delete:
            print(
                'delete_files_from_cloud',
                client.delete_files_from_cloud(file_ids_to_delete),
            )

        with open(file_path, 'rb') as file_obj:
            file_id = client.upload_file_to_cloud(file_obj)
            print('upload_file_to_cloud', file_id)
            print(
                'add_file_to_device',
                client.add_file_to_device(device_id, file_id)
            )
        device_file_list = client.device_files(device_id)
        print('device_files', device_file_list)
        print(
            'delete_files_from_device',
            client.delete_files_from_device(device_id, [file_name]),
        )
        print(
            'delete_files_from_cloud',
            client.delete_files_from_cloud([file_id]),
        )

        print(
            'add_or_update_playlist',
            client.add_or_update_playlist(
                device_id,
                TEST_PLAYLIST_NAME,
                device_file_list,
            ),
        )
        print(
            'use_playlist',
            client.use_playlist(device_id, TEST_PLAYLIST_NAME),
        )
        print('device_playlists', client.device_playlists(device_id))
        print('active_playlist_name', client.active_playlist_name(device_id))
        print(
            'delete_playlist',
            client.delete_playlist(device_id, TEST_PLAYLIST_NAME),
        )

        print('stop_device', client.stop_device(device_id))
