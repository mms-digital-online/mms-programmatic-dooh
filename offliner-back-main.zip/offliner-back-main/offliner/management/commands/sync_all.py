import logging

from django.core.management.base import BaseCommand

from offliner.tasks import sync_all_devices


log = logging.getLogger(__name__)


class Command(BaseCommand):
    help = 'Hello World'

    def handle(self, *args, **options):
        sync_all_devices.delay()
