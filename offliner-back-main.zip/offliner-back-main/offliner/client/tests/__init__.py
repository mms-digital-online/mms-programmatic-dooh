from django.test import TestCase

from offliner.client import TaskStatusEnum, DseeClient


MAX_RETRIES = 60


class DseeClientTestCase(TestCase):

    def setUp(self):
        self.client = DseeClient.get_instance()
        devices_list_data = self.client.devices_list()
        self.device_id = devices_list_data[0]['id']

    def tearDown(self):
        self.client.save_token()

    def _check_task_status(self, task_id, task_type, wait_for_completion=True):
        if wait_for_completion:
            task_status = self.client.wait_for_task_to_complete(
                self.device_id, task_id, task_type,
            )
        else:
            task = self.client.get_task_by_id(
                self.device_id, task_id=task_id, task_type=task_type,
            )
            task_status = TaskStatusEnum(task['taskStatus'])
        self.assertIsNot(task_status, None)
        self.assertIn(
            task_status,
            (TaskStatusEnum.FINISHED, TaskStatusEnum.PROCESSING),
        )
