import tempfile

from PIL import Image

from offliner.client.enums import TaskTypeEnum
from offliner.client.tests import DseeClientTestCase

TEST_FILE_RELATIVE_PATH = '../../media/files/black_image.jpg'
TEST_FILE_2_RELATIVE_PATH = '../../media/files/white_image.jpg'
TEST_PLAYLIST_NAME = 'test_custom_playlist.txt'


def create_file():
    image = Image.new("RGB", (1, 1), 'black')
    temp_file = tempfile.NamedTemporaryFile(suffix='.jpg')
    temp_file.write(image.tobytes())
    temp_file.seek(0)
    return temp_file


class DseeClientMediaClientTestCase(DseeClientTestCase):
    def setUp(self):
        super().setUp()

        # test_file_path = create_file()
        self.test_file = create_file()
        self.test_file_id = self.client.upload_file_to_cloud(self.test_file)

        # test_file_path_2 = create_file()
        self.test_file_2 = create_file()
        self.test_file_2_id = self.client.upload_file_to_cloud(self.test_file_2)

    def tearDown(self):
        self.test_file.close()
        self.test_file_2.close()
        self.client.delete_files_from_cloud([self.test_file_id])
        self.client.delete_files_from_cloud([self.test_file_2_id])
        super().tearDown()

    def test_cloud_file_list(self):
        file_data = self.client.get_cloud_file_by_id(self.test_file_id)
        self.assertIsNot(file_data, None)

    def test_add_file_to_device(self):
        task_id = self.client.add_file_to_device(
            self.device_id,
            self.test_file_id,
        )['taskIds'][0]
        self._check_task_status(task_id, TaskTypeEnum.DOWNLOAD_VIDEO)

        file_info = self.client.device_file_info(self.device_id, self.test_file_id, attr_name='id')
        self.assertIsNotNone(file_info)

        task_id = self.client.delete_files_from_device(
            self.device_id, [file_info['name']],
        )['taskIds'][0]
        self._check_task_status(task_id, TaskTypeEnum.DELETE_FILE, False)

    def test_multiple_file_occurrence_in_playlist(self):
        playlist_file_order = (
            self.test_file_id,
            self.test_file_id,
            self.test_file_2_id,
            self.test_file_2_id,
            self.test_file_2_id,
            self.test_file_id,
            self.test_file_2_id,
            self.test_file_2_id,
        )

        task_ids = []
        task_ids.extend(
            self.client.add_file_to_device(
                self.device_id, self.test_file_id,
            )['taskIds']
        )
        task_ids.extend(
            self.client.add_file_to_device(
                self.device_id, self.test_file_2_id,
            )['taskIds']
        )
        self.client.wait_for_tasks_to_complete(self.device_id, task_ids)

        device_file_dict = self.client.device_file_dict(self.device_id)

        playlist_files_names = [device_file_dict[f_id] for f_id in playlist_file_order]

        self.client.add_or_update_playlist(
            self.device_id,
            TEST_PLAYLIST_NAME,
            playlist_files_names,
        )

        result = self.client.playlist_files(self.device_id, TEST_PLAYLIST_NAME)
        self.assertSequenceEqual(result, playlist_files_names)

        task_id = self.client.delete_playlist(
            self.device_id, TEST_PLAYLIST_NAME,
        )['taskIds'][0]
        self._check_task_status(task_id, TaskTypeEnum.DELETE_PLAYLIST, False)
