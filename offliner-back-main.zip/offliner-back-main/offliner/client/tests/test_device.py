

from offliner.client.enums import TaskTypeEnum, DeviceStatusEnum
from offliner.client.tests import DseeClientTestCase

TEST_PLAYLIST_NAME = 'test_empty_playlist.txt'


class DseeClientDeviceClientTestCase(DseeClientTestCase):

    def test_turning_on(self):
        result = self.client.run_device(self.device_id)
        self.assertIn('taskIds', result)
        task_id = result['taskIds'][0]
        self._check_task_status(task_id, TaskTypeEnum.RUN_DEVICE, False)

    def test_turning_off(self):
        result = self.client.stop_device(self.device_id)
        self.assertIn('taskIds', result)
        task_id = result['taskIds'][0]
        self._check_task_status(task_id, TaskTypeEnum.STOP_DEVICE, False)

    def test_device_info(self):
        result = self.client.device_info(self.device_id)
        self.assertNotEqual(result, None)
        self.assertIn('status', result)
        self.assertIn(
            DeviceStatusEnum(result['status']),
            (DeviceStatusEnum.ONLINE, DeviceStatusEnum.OFFLINE),
        )

    def test_playlists(self):
        result = self.client.add_or_update_playlist(
            self.device_id,
            TEST_PLAYLIST_NAME,
            [],
        )
        self.assertIs(result['success'], True)
        self.assertIn('taskIds', result)
        task_id = result['taskIds'][0]
        self._check_task_status(task_id, TaskTypeEnum.UPDATE_LIST)

        task_id = self.client.use_playlist(
            self.device_id, TEST_PLAYLIST_NAME,
        )['taskIds'][0]
        self._check_task_status(task_id, TaskTypeEnum.USE_PLAYLIST)

        active_playlist = self.client.active_playlist_name(self.device_id)
        self.assertEqual(active_playlist, TEST_PLAYLIST_NAME)

        task_id = self.client.delete_playlist(
            self.device_id, TEST_PLAYLIST_NAME,
        )['taskIds'][0]
        self._check_task_status(task_id, TaskTypeEnum.DELETE_PLAYLIST, False)
