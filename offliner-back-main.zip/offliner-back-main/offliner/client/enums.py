from enum import Enum


class PlaylistActionEnum(Enum):
    DELETE = 1
    USE = 2


class TaskTypeEnum(Enum):
    DOWNLOAD_VIDEO = 1
    RUN_DEVICE = 2
    STOP_DEVICE = 3
    UPDATE_LIST = 4
    PLAY_VIDEO = 14
    DELETE_FILE = 16
    DELETE_PLAYLIST = 20
    USE_PLAYLIST = 21
    RESTART = 31


class TaskStatusEnum(Enum):
    TRANSCODING = 1
    PROCESSING = 2
    FINISHED = 3
    FAILED = 4
    TIME_OUT = 5


class DeviceStatusEnum(Enum):
    ONLINE = 1
    OFFLINE = 2
