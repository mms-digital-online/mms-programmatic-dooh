import logging
from time import sleep
from typing import List

import magic
import os

from django.conf import settings
from django.utils import timezone

from httpapiclient import ApiServerError

from offliner.client.enums import TaskTypeEnum, TaskStatusEnum, DeviceStatusEnum

log = logging.getLogger(__name__)


def get_file_name(file_object) -> str:
    """
    Get file name from file object that returned from `open` builtin
    """
    return os.path.split(file_object.name)[1]


def get_file_content_type(file_object) -> str:
    """
    Get content type from file object that returned from `open` builtin
    """
    mime_info = magic.from_buffer(
        file_object.read(1024),
        mime=True,
    )
    file_object.seek(0)
    return mime_info


def update_files_in_cloud(client, files):
    cloud_file_list = client.cloud_files()
    cloud_file_names = {x['name'] for x in cloud_file_list}

    new_file_names = {f.name for f in files}
    file_ids_to_delete = [
        x['id'] for x in cloud_file_list
        if x['name'] not in new_file_names
    ]
    if file_ids_to_delete:
        client.delete_files_from_cloud(file_ids_to_delete)

    for file in files:
        if file.name not in cloud_file_names:
            client.upload_file_to_cloud(file.file)


def check_if_device_exists(client, device_id) -> bool:
    try:
        client.device_info(device_id)
    except ApiServerError as e:
        if abs(e.args[0]['app_code']) in (404, 403):
            return False
        else:
            raise e
    return True


def check_if_device_online(client, device_id) -> bool:
    result = client.device_info(device_id)
    return DeviceStatusEnum(result['status']) == DeviceStatusEnum.ONLINE


def update_files_on_device(client, files, device_id) -> bool:

    def upload_files_by_ids(file_ids):
        _task_to_file_ids = {}
        for file_id in file_ids:
            if file_id not in device_file_dict:
                task_data = client.add_file_to_device(device_id, file_id)
                _task_to_file_ids[task_data['taskIds'][0]] = file_id
        return _task_to_file_ids

    file_names = {file.name for file in files}
    cloud_file_dict = client.cloud_file_dict()
    device_file_dict = client.device_file_dict(device_id)

    # delete excess files
    file_ids_to_delete = list(device_file_dict.keys() - {cloud_file_dict.get(name) for name in file_names})
    device_filenames_to_delete = [device_file_dict[file_id] for file_id in file_ids_to_delete]
    if device_filenames_to_delete:
        task_data = client.delete_files_from_device(device_id, device_filenames_to_delete)
        client.wait_for_task_to_complete(device_id, task_data['taskIds'][0], TaskTypeEnum.DELETE_FILE)

    # upload files
    file_ids_to_upload = [cloud_file_dict[file_name] for file_name in file_names if file_name in cloud_file_dict]
    task_to_file_ids = upload_files_by_ids(file_ids_to_upload)

    unfinished_tasks_and_statuses = client.wait_for_tasks_to_complete(
        device_id, task_to_file_ids.keys(), TaskTypeEnum.DOWNLOAD_VIDEO,
    )
    for _ in range(settings.DSEE_TASK_TIMEOUT_MAX_RETRIES):
        if not unfinished_tasks_and_statuses:
            return True
        timed_out_tasks = [
            task_id for task_id, status in unfinished_tasks_and_statuses.items() if status == TaskStatusEnum.TIME_OUT
        ]
        task_to_file_ids = upload_files_by_ids([task_to_file_ids[task_id] for task_id in timed_out_tasks])
        unfinished_tasks_and_statuses = client.wait_for_tasks_to_complete(
            device_id, task_to_file_ids.keys(), TaskTypeEnum.DOWNLOAD_VIDEO,
        )
    return False


def wait_for_files_to_appear_on_device(client, files, device_id) -> List[str]:
    """ Returns files names that are not on device yet """
    cloud_file_dict = client.cloud_file_dict()
    needed_files_dict = {cloud_file_dict[file.name]: file.name for file in files if file.name in cloud_file_dict}
    device_file_ids = set()
    for _ in range(settings.DSEE_TASK_WAITING_MAX_RETRIES):
        device_file_ids = set(client.device_files(device_id, attr_name='id'))
        if needed_files_dict.keys() - device_file_ids:
            sleep(settings.DSEE_TASK_WAITING_INTERVAL)
            continue
        return []
    return [name for file_id, name in needed_files_dict.items() if file_id not in device_file_ids]


def make_playlist_name():
    return f'playlist for {timezone.localtime().date()}'


def create_playlist(client, files_iterator, device_id) -> bool:
    def device_file_name_iterator():
        cloud_file_dict = client.cloud_file_dict()
        device_file_dict = client.device_file_dict(device_id)

        for f in files_iterator:
            if f.name not in cloud_file_dict:
                log.warning('File "%s" not present in Dsee cloud', f.name)
                continue
            if cloud_file_dict[f.name] not in device_file_dict:
                device_file_dict = client.device_file_dict(device_id)
                if cloud_file_dict[f.name] not in device_file_dict:
                    log.warning(
                        'File "%s" with id=%s not present on device with external_id=%s',
                        f.name, cloud_file_dict[f.name], device_id
                    )
                    continue
            yield device_file_dict[cloud_file_dict[f.name]]

    playlist_data = client.make_playlist_file_structure(device_id, device_file_name_iterator())

    playlist_name = make_playlist_name()
    task_data = client.post_playlist(
        device_id,
        playlist_name,
        playlist_data,
    )
    task_status = client.wait_for_task_to_complete(device_id, task_data['taskIds'][0], TaskTypeEnum.UPDATE_LIST)
    if task_status is not TaskStatusEnum.FINISHED:
        return False
    task_data = client.use_playlist(device_id, playlist_name)
    task_status = client.wait_for_task_to_complete(device_id, task_data['taskIds'][0], TaskTypeEnum.USE_PLAYLIST)
    if task_status is not TaskStatusEnum.FINISHED:
        return False
    if not client.playlist_files(device_id, playlist_name):
        return False
    return True


def start_device(client, device_id):
    task_data = client.run_device(device_id)
    client.wait_for_task_to_complete(device_id, task_data['taskIds'][0], TaskTypeEnum.RUN_DEVICE)
    client.play_file(device_id, 0)
