from django.conf import settings


class RedisTokenStorage:

    def __init__(self):
        try:
            from django_redis import get_redis_connection
        except ImportError:
            raise Exception("Can't get default Redis connection")
        else:
            self.redis_client = get_redis_connection()

    def get_token(self):
        token = self.redis_client.rpop(settings.REDIS_TOKEN_STORAGE_KEY)
        if token is not None:
            return token.decode()

    def save_token(self, token):
        self.redis_client.rpush(settings.REDIS_TOKEN_STORAGE_KEY, token)
