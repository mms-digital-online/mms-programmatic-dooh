import json
import logging

from itertools import groupby
from time import sleep
from typing import List, Any, Dict, Optional, Iterator

from django.conf import settings

from httpapiclient import BaseApiClient
from httpapiclient.mixins import JsonResponseMixin, HelperMethodsMixin

from offliner.client.enums import (
    TaskTypeEnum, PlaylistActionEnum, TaskStatusEnum,
)
from offliner.client.token_storage import RedisTokenStorage
from offliner.client.utils import get_file_name, get_file_content_type

log = logging.getLogger(__name__)


class S3Client(HelperMethodsMixin, BaseApiClient):

    def upload_file(self, file_url, file_obj):

        return self.put(
            file_url,
            data=file_obj,
            headers={
                'content-type': get_file_content_type(file_obj)
            }
        )


class DseeClient(JsonResponseMixin, HelperMethodsMixin, BaseApiClient):
    base_url = settings.DSEE_SYSTEM_URL
    token_url = 'aquarius/rest/v1/token'

    def __init__(self, username, password):
        super().__init__()
        self.username = username
        self.password = password
        self._token_data = None

    def clean_response(self, response, request):
        ret = super().clean_response(response, request)
        if ret['code'] == 403:
            raise AuthError(ret.get('msg'))
        if ret['code'] != response.status_code:
            raise self.ServerError(level='app', reason='Status code in body != HTTP status code',
                                   app_code=ret['code'], http_status=response.status_code)
        return ret['data']

    def request(self, request, *args, **kwargs):
        if self.token_data is None and request.url != self.token_url:
            self.assign_token()

        try:
            return super().request(request, *args, **kwargs)
        except AuthError:
            log.info('Invalid token, refreshing...')
            self.assign_token(force_new=True)
        return super().request(request, *args, **kwargs)

    def _get_new_token(self):
        self.token_data = None
        return self.post(self.token_url, json={
            'username': self.username,
            'password': self.password,
        })['token']

    @property
    def token_data(self):
        return self._token_data

    @token_data.setter
    def token_data(self, data):
        self._token_data = data

        if data is None:
            self.session.headers.pop('Authorization', None)
        else:
            self.session.headers['Authorization'] = f"{data['token_type']} {data['access_token']}"

    def user_info(self):
        return self.get('manage-platform/rest/v2/user')['user']

    def device_info(self, device_id):
        return self.get(
            f'manage-platform/rest/v2/device/{device_id}',
            params={'language': 2}
        )['device']

    def devices_list(self):
        return self.get('manage-platform/rest/v2/devices')['devices']

    def task_list(
            self,
            device_id: int,
            page_no: int = 1,
            page_size: int = settings.DSEE_TASK_REQUEST_PAGE_SIZE,
            task_type: Optional[TaskTypeEnum] = None,
            task_status: Optional[TaskStatusEnum] = None
    ):
        params = [
            ('id', device_id),
        ]
        if page_no is not None:
            params.append(('pageNo', page_no))
        if page_size is not None:
            params.append(('pageSize', page_size))
        if task_type is not None:
            params.append(('taskType', task_type.value))
        if task_status is not None:
            params.append(('taskStatus', task_status.value))

        return self.get(
            f'manage-platform/rest/v2/device/{device_id}/tasks',
            params=params,
        )['tasks']

    def get_task_by_id(
            self,
            device_id: int,
            task_id: int,
            task_type: Optional[TaskTypeEnum] = None,
            task_status: Optional[TaskStatusEnum] = None
    ):
        page = 1
        while True:
            tasks = self.task_list(
                device_id=device_id,
                page_no=page, task_type=task_type, task_status=task_status,
            )
            if not tasks:
                return
            for task_data in tasks:
                if task_data['id'] == task_id:
                    return task_data
            page += 1

    def wait_for_task_to_complete(
            self,
            device_id: int,
            task_id: int,
            task_type: Optional[TaskTypeEnum] = None,
            retry_on_timeout=True
    ) -> Optional[TaskStatusEnum]:
        status = None
        timeout_retries = settings.DSEE_TASK_TIMEOUT_MAX_RETRIES if retry_on_timeout else 1
        for _ in range(timeout_retries):
            for _ in range(settings.DSEE_TASK_WAITING_MAX_RETRIES):
                result = self.get_task_by_id(
                    device_id, task_id=task_id, task_type=task_type,
                )
                if result is None:
                    break
                status = TaskStatusEnum(result['taskStatus'])
                if status == TaskStatusEnum.PROCESSING:
                    sleep(settings.DSEE_TASK_WAITING_INTERVAL)
                else:
                    break
            if status == TaskStatusEnum.TIME_OUT:
                self.restart_task(device_id, task_id)
            else:
                break
        return status

    def wait_for_tasks_to_complete(
            self,
            device_id: int,
            task_ids: List[int],
            task_type: Optional[TaskTypeEnum] = None,
    ):
        task_statuses = {}
        task_id_set = set(task_ids)
        for _ in range(settings.DSEE_TASK_WAITING_MAX_RETRIES):
            sleep(settings.DSEE_TASK_WAITING_INTERVAL)
            task_statuses = {}
            for task_id in tuple(task_id_set):
                result = self.get_task_by_id(
                    device_id, task_id=task_id, task_type=task_type,
                )
                status = None if result is None else TaskStatusEnum(result['taskStatus'])
                if status != TaskStatusEnum.PROCESSING:
                    task_id_set.remove(task_id)
                task_statuses[task_id] = status
            if not task_id_set:
                break
        if task_id_set:
            log.warning('Tasks with ids %s were not completed in time', str(task_id_set))
        return task_statuses

    def _run_task_on_device(
            self,
            operation: TaskTypeEnum,
            device_id: Optional[int] = None,
            device_ids=None,
            data: Optional[Dict[str, Any]] = None,
    ):
        request_params = {} if data is None else dict(data)
        request_params['operation'] = operation.value
        if device_id is not None:
            request_params['deviceId'] = device_id
        elif device_ids is not None:
            request_params['deviceIds'] = device_ids
        else:
            raise Exception('Either device_id or device_ids should be set')
        return self.post(
            'manage-platform/rest/v2/task',
            data=request_params,
        )

    def restart_task(self, device_id: int, task_id: int):
        device_info = self.device_info(device_id)
        self.put(
            f'manage-platform/rest/v2/task/{task_id}/restart',
            json={
                'deviceSns': [device_info['deviceSn']]
            },
        )

    def run_device(self, device_id: int):
        return self._run_task_on_device(
            TaskTypeEnum.RUN_DEVICE,
            device_ids=device_id,
        )

    def stop_device(self, device_id: int):
        return self._run_task_on_device(
            TaskTypeEnum.STOP_DEVICE,
            device_ids=device_id,
        )

    def play_file(self, device_id: int, index: int):
        return self._run_task_on_device(
            TaskTypeEnum.PLAY_VIDEO,
            device_id=device_id,
            data={'index': index}
        )

    def device_playlists(self, device_id: int):
        return self.get(
            f'manage-platform/rest/v3/device/{device_id}/playlists'
        )['playlists']

    def active_playlist_name(self, device_id: int) -> str:
        playlists = self.device_playlists(device_id)
        for playlist_info in playlists:
            if playlist_info['enable'] is True:
                return playlist_info['name']
        return ''

    def _current_playlist_info(self, device_id: int):
        return self.get(
            f'manage-platform/rest/v2/device/{device_id}/playList',
        )['deviceInfo']

    def insert_next_and_play(
            self,
            device_id: int,
            file_name: str,
            number_of_times: int = 1,
    ):
        response = self._current_playlist_info(device_id)
        index = response['playIndex']
        file_info = self.device_file_info(device_id, file_name)
        playlist_file_structure = list(response['list'])
        playlist_name = response['currentPlayListName']
        file_info['times'] = str(number_of_times)
        playlist_file_structure.insert(index + 1, file_info)

        task_id = self.post_playlist(
            device_id, playlist_name, playlist_file_structure,
        )['taskIds'][0]
        self.wait_for_task_to_complete(
            device_id, task_id, TaskTypeEnum.UPDATE_LIST,
        )

        self.play_file(device_id, index + 1)

    def _playlist_file_structure(self, device_id: int, playlist_name: str):
        return self.get(
            f'manage-platform/rest/v3/device/{device_id}/playlist',
            params={
                'playlistName': playlist_name
            }
        )['detail'] or []

    def playlist_files(self, device_id: int, playlist_name: str) -> List[str]:
        result: List[str] = []
        data_list = self._playlist_file_structure(device_id, playlist_name)
        for data in data_list:
            number = 1
            try:
                number = int(data['times'])
            except (ValueError, TypeError):
                pass
            if number < 0:
                number = 1

            result.extend(
                (data['name'], ) * number
            )
        return result

    def post_playlist(
            self,
            device_id: int,
            playlist_name: str,
            file_structure,
            delete_list=None,
    ):
        log.debug(
            'Posting playlist "%s" for device with external_id=%s: %s',
            playlist_name, device_id, str(file_structure),
        )
        return self.post(
            f'manage-platform/rest/v3/device/{device_id}/playlist',
            json={
                'deviceId': device_id,
                'deleteList': delete_list,
                'list': file_structure,
                'playlistName': playlist_name,
            },
        )

    def make_playlist_file_structure(self, device_id: int, file_names_iterator: Iterator[str]):
        device_file_dict = {
            x['name']: x for x in self._device_files_structure(device_id)
        }
        playlist_file_structure = []

        for file_name in file_names_iterator:
            if not playlist_file_structure or playlist_file_structure[-1]['name'] != file_name:
                if len(playlist_file_structure) == settings.DSEE_MEDIA_PER_PLAYLIST:
                    break
                data = dict(device_file_dict[file_name])
                data['times'] = 0
                playlist_file_structure.append(data)
            playlist_file_structure[-1]['times'] += 1

        return playlist_file_structure

    def add_or_update_playlist(
            self,
            device_id: int,
            playlist_name: str,
            file_list,
    ):
        device_file_dict = {
            x['name']: x for x in self._device_files_structure(device_id)
        }
        playlist_file_structure = []

        for name, group in groupby(file_list):
            data = dict(device_file_dict[name])
            data['times'] = len(tuple(group))
            playlist_file_structure.append(data)

        return self.post_playlist(
            device_id, playlist_name, playlist_file_structure,
        )

    def _manage_playlist(
            self,
            device_id: int,
            playlist_name: str,
            action: PlaylistActionEnum,
    ):
        return self.patch(
            f'manage-platform/rest/v3/device/{device_id}/playlist',
            json={
                'type': action.value,
                'playlistName': playlist_name,
            },
        )

    def use_playlist(self, device_id: int, playlist_name: str):
        return self._manage_playlist(
            device_id,
            playlist_name,
            PlaylistActionEnum.USE,
        )

    def delete_playlist(self, device_id: int, playlist_name: str):
        return self._manage_playlist(
            device_id,
            playlist_name,
            PlaylistActionEnum.DELETE,
        )

    def cloud_files(self, page_no=1, page_size=1000):
        response = self.get(
            'manage-platform/rest/v3/materials',
            params={
                'pageNo': page_no,
                'pageSize': page_size,
            }
        )
        return response['materials'] or []

    def cloud_file_dict(self):
        cloud_file_list = self.cloud_files()
        return {x['name']: x['id'] for x in cloud_file_list}

    def _get_cloud_file_by_attr(self, attr_name, attr_value):
        page = 1
        while True:
            files = self.cloud_files(page_no=page)
            if not files:
                return
            for file_data in files:
                if file_data[attr_name] == attr_value:
                    return file_data
            page += 1

    def get_cloud_file_by_id(self, file_id):
        return self._get_cloud_file_by_attr('id', file_id)

    def get_cloud_file_by_name(self, file_name):
        return self._get_cloud_file_by_attr('name', file_name)

    def upload_file_to_cloud(self, file_obj):
        file_name = get_file_name(file_obj)

        existing_file = self.get_cloud_file_by_name(file_name)
        if existing_file is not None:
            return existing_file['id']

        self.post(
            'manage-platform/rest/v2/material/name',
            files={
                'name': (None, file_name),
            },
        )

        mime_info = get_file_content_type(file_obj)
        sign_response = self.post(
            'manage-platform/rest/v3/fileObject/sign',
            json={
                'objectName': file_name,
                'contentType': mime_info,
            },
        )

        s3_client = S3Client()
        s3_client.upload_file(sign_response['signedUrl'], file_obj)

        material_response = self.post(
            'manage-platform/rest/v3/material',
            json={
                'groupId': 0,
                'fileObjectId': sign_response['id'],
            },
        )
        return material_response['id']

    def delete_files_from_cloud(self, file_ids: List[int]):
        return self.delete(
            'manage-platform/rest/v2/materials',
            params=[('materialIds', file_id) for file_id in file_ids]
        )

    def _device_files_structure(self, device_id: int):
        return self.get(
            f'manage-platform/rest/v3/device/{device_id}/files',
        )['files'] or []

    def device_files(self, device_id: int, attr_name: str = 'name') -> List[str]:
        return [f[attr_name] for f in self._device_files_structure(device_id) if attr_name in f]

    def device_file_dict(self, device_id: int) -> Dict[int, str]:
        return {x['id']: x['name'] for x in self._device_files_structure(device_id) if 'id' in x and x['id'] != -1}

    def device_file_info(self, device_id: int, value: str, attr_name: str = 'name'):
        for file_info in self._device_files_structure(device_id):
            if file_info[attr_name] == value:
                return file_info

    def add_file_to_device(self, device_id: int, file_id: int):
        log.debug(
            'adding file with this id from device with external_id=%s: %s',
            device_id, file_id,
        )
        return self._run_task_on_device(
            TaskTypeEnum.DOWNLOAD_VIDEO,
            device_ids=device_id,
            data={
                'materialIds': file_id,
                'isSameCover': 0,
            },
        )

    def delete_files_from_device(self, device_id: int, file_names: List[str]):
        log.debug(
            'deleting these files from device with external_id=%s: %s',
            device_id, str(file_names),
        )
        return self.put(
            f'manage-platform/rest/v3/device/{device_id}/files',
            json={
                'deleteFiles': file_names,
            },
        )

    @classmethod
    def get_instance(cls):
        return cls(settings.DSEE_USERNAME, settings.DSEE_PASSWORD)

    def assign_token(self, force_new=False):
        if force_new:
            token = self._get_new_token()
        else:
            storage = RedisTokenStorage()

            token_str = storage.get_token()
            if token_str is not None:
                token = json.loads(token_str)
            else:
                token = self._get_new_token()
        self.token_data = token

    def save_token(self):
        storage = RedisTokenStorage()
        token_str = json.dumps(self.token_data)
        storage.save_token(token_str)

    def __enter__(self):
        self.assign_token()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.save_token()


class AuthError(DseeClient.ClientError):
    def __init__(self, reason):
        super().__init__(level='app', reason=reason, app_code=403)
