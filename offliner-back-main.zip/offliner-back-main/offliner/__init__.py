import os

from django.apps import AppConfig


os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'offliner.settings')


class App(AppConfig):
    name = 'offliner'
