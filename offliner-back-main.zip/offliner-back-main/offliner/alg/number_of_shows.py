import datetime

from decimal import Decimal, ROUND_HALF_UP
from collections import defaultdict
from typing import Dict, List

from offliner.alg.utils import HourKey, dict_of_objects_by_ad_campaign, time_to_end_left
from offliner.alg.working_hours import WorkingHours
from offliner.enums import DeviceTypeEnum
from offliner.models import FloatingShow, OrderedMediaForDevice
from offliner.utils import date_to_day_type


class NumberOfShows:

    _storage: Dict[int, Dict[int, Dict[HourKey, Decimal]]] = (
        defaultdict(lambda: defaultdict(lambda: defaultdict(Decimal)))
    )

    @staticmethod
    def hour_budget_to_show_number(hour: HourKey, budget: Decimal, device) -> Decimal:
        result = budget / device.get_price_per_show(hour.get_time())
        return result.quantize(Decimal('1.'), rounding=ROUND_HALF_UP)

    @staticmethod
    def _get_hours(periods: List[FloatingShow]):
        result = set()
        for period in periods:
            result.update(HourKey.get_instances_from_range(period.start_at, period.end_at))
        return result

    def __init__(self, day_date, working_hours: WorkingHours, ad_campaign_queryset, is_final):
        show_periods_qs = FloatingShow.objects.filter(
            day_of_week=date_to_day_type(day_date),
            ad_campaign__in=ad_campaign_queryset,
        )
        show_periods_by_ad_campaign = dict_of_objects_by_ad_campaign(show_periods_qs)

        budget_per_campaign = {}
        for ad_campaign in ad_campaign_queryset:
            budget_per_campaign[ad_campaign.id] = ad_campaign.get_budget_on_day(is_final=is_final)

        ordered_devices_for_media_qs = OrderedMediaForDevice.objects.filter(
            ad_campaign__in=ad_campaign_queryset,
            device__type=DeviceTypeEnum.cooler,
        ).select_related(
            'device'
        )
        ordered_devices_for_media_by_ad_campaign = dict_of_objects_by_ad_campaign(ordered_devices_for_media_qs)

        for c_id, periods in show_periods_by_ad_campaign.items():
            if c_id not in ordered_devices_for_media_by_ad_campaign:
                continue

            hours = self._get_hours(periods)

            overall_hours = []
            for ordered_device_for_media in ordered_devices_for_media_by_ad_campaign[c_id]:
                overall_hours.extend(hours.intersection(working_hours.get(ordered_device_for_media.device_id)))
            if not overall_hours:
                continue

            budget_per_hour = Decimal(budget_per_campaign[c_id]) / len(overall_hours)

            for ordered_device_for_media in ordered_devices_for_media_by_ad_campaign[c_id]:
                for hour in hours.intersection(working_hours.get(ordered_device_for_media.device_id)):
                    number_of_shows = self.hour_budget_to_show_number(
                        hour, budget_per_hour, ordered_device_for_media.device,
                    )
                    self._storage[ordered_device_for_media.device_id][c_id][hour] = number_of_shows

    def get(self, device_id, ad_campaign_id) -> Decimal:
        numbers = self.get_hours_and_numbers(device_id, ad_campaign_id).values()
        return Decimal(sum(numbers))

    def get_hours_and_numbers(self, device_id, ad_campaign_id) -> Dict[HourKey, Decimal]:
        default_value: Dict = {}
        return self._storage.get(device_id, default_value).get(ad_campaign_id, default_value)

    def get_time_left(self, t, device_id, ad_campaign_id) -> datetime.timedelta:
        hours = self.get_hours_and_numbers(device_id, ad_campaign_id).keys()
        return time_to_end_left(t, hours)

    def time_to_next_hour(self, t, device_id, ad_campaign_id) -> datetime.timedelta:
        hours = self.get_hours_and_numbers(device_id, ad_campaign_id).keys()
        for hour in sorted(hours):
            if hour > t:
                return hour.time_from_hour_begin(t)
        return datetime.timedelta(hours=24)

    def time_from_last_hour(self, t, device_id, ad_campaign_id) -> datetime.timedelta:
        hours = self.get_hours_and_numbers(device_id, ad_campaign_id).keys()
        for hour in sorted(hours, reverse=True):
            if hour < t:
                return hour.time_from_hour_begin(t)
        return datetime.timedelta(hours=24)
