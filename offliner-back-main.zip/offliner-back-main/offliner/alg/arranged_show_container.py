from collections import defaultdict
from typing import Dict, List

from offliner.models import ArrangedShow


class ArrangedShowContainer:
    _storage: Dict[int, List[ArrangedShow]]

    def __init__(self, day_date, is_final):
        self._storage = defaultdict(list)
        self._day_date = day_date
        self._is_final = is_final

    def add(self, device_id, ad_campaign_id, media, time):
        arranged_show = ArrangedShow(
            device_id=device_id,
            ad_campaign_id=ad_campaign_id,
            media=media,
            index=len(self._storage[device_id]),
            date=self._day_date,
            time=time,
            is_final=self._is_final,
        )
        self._storage[device_id].append(arranged_show)

    def clear_schedule(self, date_list=None):
        if date_list is None:
            date_list = (self._day_date, )
        ArrangedShow.objects.filter(date__in=date_list, is_final=self._is_final).delete()

    def clear_schedule_for_previous_days(self):
        ArrangedShow.objects.filter(date__lt=self._day_date, is_final=self._is_final).delete()

    def store(self):
        for objs in self._storage.values():
            ArrangedShow.objects.bulk_create(objs)
