import datetime

from itertools import groupby
from operator import attrgetter
from typing import Optional, Iterable, Set

from django.utils import timezone


def time_plus_timedelta(t: datetime.time, td: datetime.timedelta) -> Optional[datetime.time]:
    day = timezone.localtime().date()
    dt = datetime.datetime.combine(timezone.localtime().date(), t)
    dt += td
    if dt.date() == day:
        return dt.time()
    return None


def time_diff(t1: datetime.time, t2: datetime.time) -> datetime.timedelta:
    dt1 = datetime.datetime.combine(timezone.localtime().date(), t1)
    dt2 = datetime.datetime.combine(timezone.localtime().date(), t2)
    result = dt1 - dt2
    return result


def dict_of_objects_by_ad_campaign(qs):
    qs = qs.order_by('ad_campaign')
    return {
        key: list(objs) for key, objs in groupby(qs, key=attrgetter('ad_campaign_id'))
    }


def time_is_in_hours(t: datetime.time, hours: Iterable['HourKey']):
    hour = HourKey(t)
    return hour in hours


def time_to_end_left(t: datetime.time, hours: Iterable['HourKey']) -> datetime.timedelta:
    result = datetime.timedelta()
    for hour in hours:
        if hour > t:
            result += datetime.timedelta(hours=1)
        elif hour == t:
            result += hour.time_to_hour_end(t)
    return result


class Key:
    def __init__(self, data):
        self.data = data

    def __eq__(self, another):
        return hasattr(another, 'data') and self.data == another.data

    def __hash__(self):
        return hash(self.data)


class HourKey(Key):
    def __init__(self, data):
        data = self._canonize_value(data)
        super().__init__(data)

    @staticmethod
    def _canonize_value(value) -> datetime.time:
        if isinstance(value, HourKey):
            value = value.data
        if isinstance(value, datetime.datetime):
            value = value.time()
        elif not isinstance(value, datetime.time):
            raise TypeError
        return value.replace(minute=0, second=0, microsecond=0)

    @staticmethod
    def _prepare_operand(value) -> datetime.time:
        if isinstance(value, HourKey):
            right_operand = value.data
        elif isinstance(value, datetime.datetime):
            right_operand = value.time()
        elif isinstance(value, datetime.time):
            right_operand = value
        else:
            raise TypeError
        return right_operand

    @classmethod
    def get_instances_from_range(cls, time_from, time_to) -> Set['HourKey']:
        tmp_time = cls._canonize_value(time_from)
        result = set()
        while tmp_time < time_to:
            result.add(cls(tmp_time))
            if tmp_time.hour == 23:
                break
            tmp_time = tmp_time.replace(hour=tmp_time.hour + 1)
        return result

    def __str__(self):
        return str(self.data)

    def __eq__(self, another):
        if not isinstance(another, Key):
            another = HourKey(another)
        return super().__eq__(another)

    def __hash__(self):
        return super().__hash__()

    def __gt__(self, another):
        return self.data > self._prepare_operand(another)

    def __lt__(self, another):
        return self.data < self._prepare_operand(another)

    def time_to_hour_end(self, another) -> datetime.timedelta:
        value = self._prepare_operand(another)
        return time_diff(
            datetime.time.max.replace(hour=self.data.hour),
            value,
        )

    def time_from_hour_begin(self, another) -> datetime.timedelta:
        value = self._prepare_operand(another)
        return time_diff(self.data, value)

    def get_time(self) -> datetime.time:
        return self.data
