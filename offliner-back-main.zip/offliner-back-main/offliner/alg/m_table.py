import datetime

from dataclasses import dataclass
from typing import List, Optional

from offliner.alg.number_of_shows import NumberOfShows
from offliner.alg.utils import time_is_in_hours, time_plus_timedelta
from offliner.alg.working_hours import WorkingHours
from offliner.enums import DeviceTypeEnum
from offliner.models import Media, OrderedMediaForDevice


@dataclass
class MRow:
    media: Media
    ad_campaign_id: int
    device_id: int
    n: int  # number of unused shows
    n_initial: int  # overall number of shows
    s: datetime.timedelta  # duration of working time of device

    def p(self, t, number_of_shows: NumberOfShows) -> datetime.timedelta:

        # the proportion of the number of unused time
        x = number_of_shows.get_time_left(t, self.device_id, self.ad_campaign_id) / self.s

        # the proportion of the number of unused shows
        y = self.n / self.n_initial

        return (x - y) * self.s


class MTable:
    _rows: List[MRow]

    def __init__(self, working_hours: WorkingHours, number_of_shows: NumberOfShows, ad_campaign_queryset):
        self.working_hours = working_hours
        self.number_of_shows = number_of_shows
        self._rows = []
        ordered_devices_for_media_qs = OrderedMediaForDevice.objects.filter(
            ad_campaign__in=ad_campaign_queryset,
            device__type=DeviceTypeEnum.cooler,
        )
        for ordered_device_for_media in ordered_devices_for_media_qs:
            n = round(number_of_shows.get(
                ordered_device_for_media.device_id,
                ordered_device_for_media.ad_campaign_id,
            ))
            if n:
                self._rows.append(
                    MRow(
                        media=ordered_device_for_media.media,
                        ad_campaign_id=ordered_device_for_media.ad_campaign_id,
                        device_id=ordered_device_for_media.device_id,
                        n=n,
                        n_initial=n,
                        s=datetime.timedelta(hours=len(working_hours.get(ordered_device_for_media.device_id)))
                    )
                )

    def get_row_with_min_p(self, t, device_id):
        suitable_rows = []
        for m_row in self._rows:
            if m_row.device_id != device_id:
                continue
            next_t = time_plus_timedelta(t, m_row.media.duration)
            if next_t is None or not time_is_in_hours(next_t, self.working_hours.get(m_row.device_id)):
                continue
            shows_dict = self.number_of_shows.get_hours_and_numbers(m_row.device_id, m_row.ad_campaign_id)
            if not time_is_in_hours(t, shows_dict):
                continue
            suitable_rows.append(m_row)
        if suitable_rows:
            return min(suitable_rows, key=lambda r: r.p(t, self.number_of_shows))

    def decrease_n(self, row):
        row.n -= 1
        if row.n <= 0:
            self._rows.remove(row)

    def find_row(self, ad_campaign_id) -> Optional[MRow]:
        for row in self._rows:
            if row.ad_campaign_id == ad_campaign_id:
                return row
        return None
