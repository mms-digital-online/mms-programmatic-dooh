import datetime

from typing import Dict, Set

from offliner.alg.utils import HourKey, time_to_end_left
from offliner.enums import DeviceTypeEnum
from offliner.models import Device
from offliner.utils import date_to_day_type


class WorkingHours:
    _storage: Dict[int, Set[HourKey]]

    def __init__(self, day_date):
        self._storage = {}
        devices_qs = Device.objects.filter(type=DeviceTypeEnum.cooler).with_working_time(date_to_day_type(day_date))
        for device in devices_qs:
            self._storage[device.id] = HourKey.get_instances_from_range(device.turn_on_at, device.turn_off_at)

    def get(self, device_id) -> Set[HourKey]:
        return self._storage.get(device_id, set())

    def __iter__(self):
        for data in self._storage.items():
            yield data

    def get_min_time(self, device_id):
        return sorted(self.get(device_id))[0].data

    def get_time_to_end_left(self, t, device_id) -> datetime.timedelta:
        return time_to_end_left(t, self._storage[device_id])
