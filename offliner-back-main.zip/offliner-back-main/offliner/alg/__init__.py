import datetime
import functools

from offliner.alg.arranged_show_container import ArrangedShowContainer
from offliner.alg.m_table import MTable
from offliner.alg.number_of_shows import NumberOfShows
from offliner.alg.utils import (
    time_plus_timedelta, time_diff, dict_of_objects_by_ad_campaign, time_is_in_hours, time_to_end_left, HourKey,
)
from offliner.alg.working_hours import WorkingHours
from offliner.enums import DeviceTypeEnum
from offliner.models import AdCampaign, Device, Placeholder
from offliner.utils import date_range


class FillDevicesScheduleAlg:

    fields_involved = (
        'orderedmediafordevice_set', 'schedule', 'start_at', 'end_at', 'period', 'media_containers',
        'budget', 'day_limit', 'visible',
    )

    def __init__(self, day_date: datetime.date, is_final=True):
        self._is_final = is_final
        self._day_date = day_date
        self._placeholders = tuple(Placeholder.objects.order_by('priority').select_related('media'))
        self._devices = Device.objects.filter(type=DeviceTypeEnum.cooler).in_bulk()
        self._container = ArrangedShowContainer(day_date, is_final)

    @property
    @functools.lru_cache()
    def _ad_campaign_queryset(self):
        if self._is_final:
            ad_campaign_queryset = AdCampaign.get_ready_to_show_on_date(self._day_date)
        else:
            ad_campaign_queryset = AdCampaign.get_for_draft_schedule_on_date(self._day_date)
        return ad_campaign_queryset

    @property
    @functools.lru_cache()
    def _working_hours(self):
        return WorkingHours(self._day_date)

    @property
    @functools.lru_cache()
    def _number_of_shows(self):
        return NumberOfShows(self._day_date, self._working_hours, self._ad_campaign_queryset, self._is_final)

    @property
    @functools.lru_cache()
    def _m_table(self):
        return MTable(self._working_hours, self._number_of_shows, self._ad_campaign_queryset)

    def _run_algorithm(self):
        for device_id, hours in self._working_hours:
            t = self._working_hours.get_min_time(device_id)
            while self._working_hours.get_time_to_end_left(t, device_id):
                m_row = self._m_table.get_row_with_min_p(t, device_id)
                if m_row:
                    min_p = min(m_row.p(t, self._number_of_shows), HourKey(t).time_to_hour_end(t))
                else:
                    min_p = HourKey(t).time_to_hour_end(t)
                if min_p <= datetime.timedelta() and m_row:
                    media = m_row.media
                    ad_campaign_id = m_row.ad_campaign_id
                    self._m_table.decrease_n(m_row)
                    z = self._add(device_id, ad_campaign_id, media, t)
                else:
                    z = datetime.timedelta()
                    while True:
                        media = self._get_suitable_placeholder_media(min_p)
                        if media:
                            delta = self._add(device_id, None, media, time_plus_timedelta(t, z))
                            min_p -= delta
                            z += delta
                        else:
                            break
                z = z or datetime.timedelta(seconds=1)
                t = time_plus_timedelta(t, z)
                if t is None:
                    break

    def fill_schedule(self):
        self._run_algorithm()
        self._container.store()

    @classmethod
    def check_for_overload(cls, ad_campaign) -> bool:
        ArrangedShowContainer(None, False).clear_schedule(
            tuple(date_range(ad_campaign.start_at, ad_campaign.end_at))
        )

        alg_obj = None
        for day_date in date_range(ad_campaign.start_at, ad_campaign.end_at):
            alg_obj = cls(day_date, is_final=False)
            alg_obj.fill_schedule()
        spent = ad_campaign.get_total_spent(is_final=False)
        if spent < ad_campaign.budget:
            return False
        if alg_obj is not None:
            if alg_obj._m_table.find_row(ad_campaign.id):
                return False
        return True

    @classmethod
    def is_check_needed(cls, ad_campaign, data):
        return set(cls.fields_involved).intersection(data)

    def _add(self, device_id, ad_campaign_id, media, time) -> datetime.timedelta:
        self._container.add(device_id, ad_campaign_id, media, time)
        return media.duration + self._devices[device_id].media_switch_delay

    def _get_suitable_placeholder_media(self, duration):
        for placeholder in self._placeholders:
            if placeholder.media.duration <= duration:
                return placeholder.media

    def clear_current_schedule(self):
        self._container.clear_schedule()

    def clear_schedule_for_previous_days(self):
        self._container.clear_schedule_for_previous_days()
