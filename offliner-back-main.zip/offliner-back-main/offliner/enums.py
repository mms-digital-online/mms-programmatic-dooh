import enum


class DeviceTypeEnum(enum.IntEnum):
    cooler = 1  # Голографический экран
    city_format_1_2_x_1_8 = 2  # Сити-формат 1.2х1.8
    city_board_3_7_x_2_7 = 3  # Сити-борд 3.7х2.7
    billboard_6_x_3 = 4  # Билборд 6х3
    supersite_6_x_3 = 5  # Суперсайт 6х3
    supersite_7_x_4 = 6  # Суперсайт 7х4
    supersite_12_x_3 = 7  # Суперсайт 12х3
    super_board_12_x_4 = 8  # Супер-борд 12х4
    supersite_15_x_5 = 9  # Суперсайт 15х5
    mediascreen = 10  # Медиаэкран
    mediafacade = 11  # Медиафасад


class PlacementEnum(enum.IntEnum):
    indoor = 1
    outdoor = 2


class MimeTypeEnum(enum.IntEnum):
    image = 1
    video = 2


class ExtensionEnum(enum.IntEnum):
    gif = 1
    jpg = 2
    jpeg = 3
    png = 4
    bmp = 5

    rmvb = 6
    mkv = 7
    wmv = 8
    mp4 = 9
    avi = 10
    mov = 11
    flv = 12


class AuctionTypeEnum(enum.IntEnum):
    ppv = 1
    cpt = 2


class MediaStatusEnum(enum.IntEnum):
    selected = 1
    confirmed = 2
    moderated = 3


class AdCampaignStatusEnum(enum.IntEnum):
    active = 1
    completed = 2
    moderation = 3
    stopped = 4
    draft = 5
    rejected = 6
    start_when_ready = 7


class DayTypeEnum(enum.IntEnum):
    mon = 0
    tue = 1
    wed = 2
    thu = 3
    fri = 4
    sat = 5
    sun = 6
    hol = 7
