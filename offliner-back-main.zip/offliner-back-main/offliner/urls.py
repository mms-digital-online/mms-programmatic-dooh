from django.urls import path, include

from utils.django.urls import urlpatterns
from utils.django.routers import Router

from offliner import views
from offliner.media import views as media_views
from offliner.admin.urls import urlpatterns as admin_urls
from offliner.users.urls import urlpatterns as users_urls


router = Router()

router.register('devices', views.DeviceViewSet)
router.register('media', media_views.FilteredMediaViewSet, basename='media_filtered')
router.register('media', media_views.UnfilteredMediaViewSet, basename='media_unfiltered')
router.register('campaigns', views.FilteredAdCampaignViewSet, basename='campaigns_filtered')
router.register('campaigns', views.UnfilteredAdCampaignViewSet, basename='campaigns_unfiltered')

v1_urlpatterns = [
    path('admin/', include(admin_urls)),
    path('users/', include(users_urls)),
    *router.urls,
]

urlpatterns += [
    path('v1/', include(v1_urlpatterns)),
]
